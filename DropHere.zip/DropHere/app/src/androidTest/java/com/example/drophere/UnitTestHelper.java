package com.example.drophere;

import android.util.Log;

import com.example.drophere.DAL.BasicModels.Group;
import com.example.drophere.DAL.BasicModels.Message;
import com.example.drophere.DAL.BasicModels.Setting;
import com.example.drophere.DAL.BasicModels.Template;
import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbModel.MessageModel;
import com.example.drophere.DAL.MessageMethod;

import java.util.Calendar;
import java.util.List;
import java.util.Random;

public class UnitTestHelper {


    public static User GetDefaultUser() {
        Random rand = new Random();
        int int_random = rand.nextInt(50);

        User user = new User();
        user.Name = "User_" + int_random;
        user.Email = "abdulaleem.yousuf97@hotmail.com";
        user.Phone = "999999";
        user.Country = "ITALY";
        user.City = "Genova";

        return user;
    }

    public static User GetUser() {
        Random rand = new Random();
        int int_random = rand.nextInt(50);

        User user = new User();
        user.Name = "User_" + int_random;
        user.Email = "user_" + int_random + "@hot.com";
        user.Phone = "234234";
        user.Country = "ITALY";
        user.City = "Genova";

        return user;
    }
    public static Template GetTemplate() {
        Random rand = new Random();
        int int_random = rand.nextInt(50);

        Template template = new Template();
        template.Name = "User_" + int_random;
        template.TemplateText = "Template_" + int_random;

        return template;
    }
    public static Setting GetSetting() {
        Random rand = new Random();
        int int_random = rand.nextInt(50);

        Setting setting = new Setting();
        setting.Email = "ali" + int_random + "@hotmail.com";
        setting.Password = "Password_" + int_random;
        setting.SIM = 2;
        setting.Signature = "Signature_" + int_random;

        return setting;
    }


    public static Setting GetDefaultSetting() {
        Random rand = new Random();
        int int_random = rand.nextInt(50);

        Setting setting = new Setting();
        setting.Email = "galioistheway@gmail.com";
        setting.Password = "Durand1995";
        setting.SIM = 2;
        setting.Signature = "Signature_" + int_random;

        return setting;
    }

    public static Message GetMessage(MessageMethod method) {
        Random rand = new Random();
        int int_random = rand.nextInt(50);
        Calendar calendar = Calendar.getInstance(); // gets a calendar using the default time zone and locale.
        calendar.add(Calendar.SECOND, 5);
        System.out.println(calendar.getTime());

        Message Message = new Message();
        Message.MessageTypeId = method.value;
        Message.DateTime = MessageModel.GetDate(calendar);
        Message.Subject = "Subject_" + int_random;
        Message.MessageText = "Message_" + int_random;
        Message.MessageMethod = method;
        return Message;
    }

    public static Group GetGroup() {
        Random rand = new Random();
        int int_random = rand.nextInt(50);

        Group group = new Group();
        group.Name = "Group_" + int_random;
        return group;
    }

    public static void LogUser(User user) {
        Log.d("UnitTest", "User -> Id: " + user.Id + ", Name: " + user.Name + ", Email: " + user.Email + ", Phone: " + user.Phone);
    }

    public static void LogGroupUsers(Group group, List<User> usersList) {

        for (User user : usersList) {
            Log.d("UnitTest", "Group User -> Group: " + group.Name + ", Id: " + user.Id + ", Name: " + user.Name + ", Email: " + user.Email + ", Phone: " + user.Phone);
        }
    }

    public static void LogMessages(List<Message> messages) {

        for (Message message : messages) {
            Log.d("UnitTest", "Message -> Id: " + message.Id + ", Type: " + message.MessageTypeId + " , TYPED:" + message.MessageMethod + ", UserID: " + message.UserId + ", GroupID: " + message.GroupId + ", Subject: " + message.Subject + ", Message: " + message.MessageText + ", DateTime: " + message.DateTime + ", MediaPath: " + message.MediaPath + ", Status: " + message.Status);
        }
    }
}
