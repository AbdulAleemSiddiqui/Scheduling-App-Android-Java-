package com.example.drophere;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import android.content.Context;
import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import com.example.drophere.DAL.BasicModels.Group;
import com.example.drophere.DAL.BasicModels.GroupUser;
import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbModel.GroupModel;
import com.example.drophere.DAL.DbModel.GroupUserModel;
import com.example.drophere.DAL.DbModel.UserModel;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

@RunWith(AndroidJUnit4.class)
public class GroupUserUnitTest {

    GroupUserModel groupUserModel;
    GroupModel groupModel;
    UserModel userModel;

    @Before
    public void Setup(){
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();

        groupUserModel = new GroupUserModel(appContext, "",null,1);
        userModel = new UserModel(appContext,"",null,1);
        groupModel = new GroupModel(appContext,"",null,1);
    }

    @Test
    public void AddGroupUser(){

        Group group = UnitTestHelper.GetGroup();
        long groupId = groupModel.AddGroup(group);

            User user = UnitTestHelper.GetUser();
            long userId = userModel.AddUser(user);

            GroupUser groupUser = new GroupUser();
            groupUser.UserId=(int)userId;
            groupUser.GroupId=(int)groupId;

            long groupUserId = groupUserModel.AddGroupUser(groupUser);

            assertTrue(groupUserId>0);
    }

    @Test
    public void ShowGroupUser(){

        Group group = UnitTestHelper.GetGroup();
        long groupId = groupModel.AddGroup(group);

        for (int i = 0; i < 3; i++) {
            User user = UnitTestHelper.GetUser();
            long userId = userModel.AddUser(user);

            GroupUser groupUser = new GroupUser();
            groupUser.UserId=(int)userId;
            groupUser.GroupId=(int)groupId;

            long groupUserId = groupUserModel.AddGroupUser(groupUser);
        }

        List<User> groupUsers = groupUserModel.GetGroupUsers((int)groupId);

        UnitTestHelper.LogGroupUsers(group, groupUsers);
        assertTrue(groupUsers.size()>0);
    }

    @Test
    public void DeleteGroupUser(){

        Group group = UnitTestHelper.GetGroup();
        long groupId = groupModel.AddGroup(group);
        long userId =0;
        int userSize = 3;

        for (int i = 0; i < userSize; i++) {
            User user = UnitTestHelper.GetUser();
            userId = userModel.AddUser(user);

            GroupUser groupUser = new GroupUser();
            groupUser.UserId=(int)userId;
            groupUser.GroupId=(int)groupId;

            long groupUserId = groupUserModel.AddGroupUser(groupUser);
        }

        List<User> groupUsers = groupUserModel.GetGroupUsers((int)groupId);
        UnitTestHelper.LogGroupUsers(group, groupUsers);
        assertEquals(groupUsers.size(), userSize);
        Log.d("UnitTest", "User Size: "+groupUsers.size());

        //Delete Last user
        GroupUser groupUserToDelete = new GroupUser();
        groupUserToDelete.UserId = (int)userId;
        groupUserToDelete.GroupId = (int)groupId;
        groupUserModel.RemoveGroupUser(groupUserToDelete);

        groupUsers = groupUserModel.GetGroupUsers((int)groupId);
        UnitTestHelper.LogGroupUsers(group, groupUsers);

        assertTrue(groupUsers.size() != userSize);
        Log.d("UnitTest", "User Size: "+groupUsers.size());
    }

}
