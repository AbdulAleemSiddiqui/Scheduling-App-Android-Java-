package com.example.drophere;

import android.content.Context;
import android.util.Log;
import android.widget.HeaderViewListAdapter;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

import com.example.drophere.DAL.BasicModels.Setting;
import com.example.drophere.DAL.DbModel.SettingModel;

import java.util.List;
import java.util.Random;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class SettingUnitTest {
   /* @Test
    public void useAppContext() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertEquals("com.example.drophere", appContext.getPackageName());
    }*/

    SettingModel settingModel;

    @Before
    public void Setup(){
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();

        settingModel = new SettingModel(appContext, "",null,1);
    }

    @Test
    public  void AddSetting(){

        Setting setting = UnitTestHelper.GetSetting();
        settingModel.AddSetting(setting);

        List<Setting> settingList = settingModel.ListSettings();

        Log.d("UnitTest","settings size: "+ settingList.size());
        assertTrue(settingList.size()>0);
    }
    @Test
    public  void UpdateSetting(){
        Setting setting = UnitTestHelper.GetSetting();
        long id =  settingModel.AddSetting(setting);

        Setting updatedSetting = settingModel.SearchSetting((int)id);
        updatedSetting.Email = "Updated_Email";
        settingModel.UpdateSetting(updatedSetting);
        Log.d("UnitTest","Updated Setting -> Id: "+updatedSetting.Id+", Email: "+ updatedSetting.Email  + ", Pass: "+updatedSetting.Password);

        Setting searchedSetting = settingModel.SearchSetting((int)id);

        Log.d("UnitTest","Searched Setting -> Id: "+updatedSetting.Id+", Email: "+ updatedSetting.Email  + ", Pass: "+updatedSetting.Password);
        assertEquals(searchedSetting.Email,  updatedSetting.Email);
    }
    @Test
    public void ShowSetting(){
        Setting setting = UnitTestHelper.GetSetting();
        long id = settingModel.AddSetting(setting);

        List<Setting> settingList = settingModel.ListSettings();

        Log.d("UnitTest","settings size: "+ settingList.size() + ", Id: "+ id);
        assertTrue(settingList.size()>0);


        for (Setting s: settingList) {
            Log.d("UnitTest","Setting -> Id: "+s.Id + ", Email: "+s.Email
                    +", Pass: "+s.Password
                    +", SIM: "+s.SIM
                    );
        }
    }
    @Test
    public void SearchSetting(){
        List<Setting> settingList = settingModel.ListSettings();

        Log.d("UnitTest","Setting size: "+settingList.size());

        for (Setting setting: settingList) {

            Setting searchedSetting = settingModel.SearchSetting(setting.Id);
            assertTrue(searchedSetting!=null);
            Log.d("UnitTest","Setting -> Id: "+setting.Id + ", Email: "+setting.Email+", Pass: "+setting.Password);

        }
    }
    @Test
    public void DeleteSetting(){
        Random rand = new Random();
        int int_random = rand.nextInt(50);

        Setting setting = UnitTestHelper.GetSetting();
        long id = settingModel.AddSetting(setting);

        Log.d("UnitTest","Setting Added: "+ id );

        settingModel.DeleteSetting();

        Setting searchSetting = settingModel.SearchSetting((int)id);
        assertTrue(searchSetting.Id == 0);

        Log.d("UnitTest","Setting -> Id: "+setting.Id + ", Email: "+setting.Email+", Pass: "+setting.Password);
    }
}