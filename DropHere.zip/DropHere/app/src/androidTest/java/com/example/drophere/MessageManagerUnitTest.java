package com.example.drophere;

import static org.junit.Assert.assertTrue;

import android.content.Context;
import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import com.example.drophere.Controller.Managers.SMSManager;
import com.example.drophere.DAL.BasicModels.Group;
import com.example.drophere.DAL.BasicModels.GroupUser;
import com.example.drophere.DAL.BasicModels.Message;
import com.example.drophere.DAL.BasicModels.Setting;
import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbModel.GroupModel;
import com.example.drophere.DAL.DbModel.GroupUserModel;
import com.example.drophere.DAL.DbModel.MessageModel;
import com.example.drophere.DAL.DbModel.SettingModel;
import com.example.drophere.DAL.DbModel.UserModel;
import com.example.drophere.DAL.MessageMethod;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

@RunWith(AndroidJUnit4.class)

public class MessageManagerUnitTest
{
    com.example.drophere.DAL.DbModel.MessageModel messageModel;
    GroupModel groupModel;
    UserModel userModel;
    GroupUserModel groupUserModel;
    SettingModel settingModel;

    Context appContext;

    @Before
    public void Setup(){
         appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();

        messageModel = new MessageModel(appContext, "",null,1);
        userModel = new UserModel(appContext,"",null,1);
        groupModel = new GroupModel(appContext,"",null,1);
        groupUserModel = new GroupUserModel(appContext,"",null,1);
        settingModel = new SettingModel(appContext,"",null,1);
    }

    @Test
    public  void ScheduleSMSToIndividual() throws InterruptedException {
        Setting setting = UnitTestHelper.GetDefaultSetting();

        User user = UnitTestHelper.GetDefaultUser();
        long userId = userModel.AddUser(user);

        Message message = UnitTestHelper.GetMessage(MessageMethod.SMS);
        message.UserId=(int)userId;

        Calendar calendar = Calendar.getInstance(); // gets a calendar using the default time zone and locale.
        calendar.add(Calendar.MINUTE, 0);
        System.out.println(calendar.getTime());

        message.DateTime = MessageModel.GetDate(calendar);
        long MessageId = messageModel.AddMessage(message);

        message = messageModel.SearchMessage((int)MessageId);

        Log.d("UnitTest", "Message status before sending it : "+message.Status);
        assertTrue(!message.Status);

        SMSManager smsManager = new SMSManager(appContext,message,setting);

        Message finalMessage = message;
        UnitTestHelper.LogMessages(new ArrayList<Message>(){{add(finalMessage);}});
        smsManager.Schedule(calendar);

        Thread.sleep(10000);

        Message searchedMessage = messageModel.SearchMessage((int)MessageId);

        Log.d("UnitTest", "Message status after sending it : "+searchedMessage.Status);
        assertTrue(searchedMessage.Status);
    }

    @Test
    public  void ScheduleEmailToIndividual() throws InterruptedException {
        Setting setting = UnitTestHelper.GetDefaultSetting();

        User user = UnitTestHelper.GetDefaultUser();
        long userId = userModel.AddUser(user);

        Message message = UnitTestHelper.GetMessage(MessageMethod.EMAIL);
        message.UserId=(int)userId;

        Calendar calendar = Calendar.getInstance(); // gets a calendar using the default time zone and locale.
        calendar.add(Calendar.MINUTE, 1);
        System.out.println(calendar.getTime());

        message.DateTime = MessageModel.GetDate(calendar);
        long MessageId = messageModel.AddMessage(message);

        message = messageModel.SearchMessage((int)MessageId);

        SMSManager smsManager = new SMSManager(appContext,message,setting);

        Message finalMessage = message;
        UnitTestHelper.LogMessages(new ArrayList<Message>(){{add(finalMessage);}});
        smsManager.Schedule(calendar);

        Thread.sleep(90000);
    }



    @Test
    public  void ScheduleSMSToGroup() throws InterruptedException {
        Setting setting = UnitTestHelper.GetDefaultSetting();

        Group group = UnitTestHelper.GetGroup();
        long groupId = groupModel.AddGroup(group);

        for (int i = 0; i < 3; i++) {
            User user = UnitTestHelper.GetDefaultUser();
            long userId = userModel.AddUser(user);

            GroupUser groupUser = new GroupUser();
            groupUser.UserId=(int)userId;
            groupUser.GroupId=(int)groupId;

            long groupUserId = groupUserModel.AddGroupUser(groupUser);
        }

        Message message = UnitTestHelper.GetMessage(MessageMethod.SMS);
        message.GroupId = (int)groupId;

        Calendar calendar = Calendar.getInstance(); // gets a calendar using the default time zone and locale.
        calendar.add(Calendar.MINUTE, 1);
        System.out.println(calendar.getTime());

        message.DateTime = MessageModel.GetDate(calendar);
        long MessageId = messageModel.AddMessage(message);

        message = messageModel.SearchMessage((int)MessageId);

        SMSManager smsManager = new SMSManager(appContext,message,setting);

        Message finalMessage = message;
        UnitTestHelper.LogMessages(new ArrayList<Message>(){{add(finalMessage);}});
        smsManager.Schedule(calendar);

        Thread.sleep(90000);
    }

    @Test
    public  void ScheduleEmailToGroup() throws InterruptedException {
        Setting setting = UnitTestHelper.GetDefaultSetting();

        Group group = UnitTestHelper.GetGroup();
        long groupId = groupModel.AddGroup(group);

        for (int i = 0; i < 3; i++) {
            User user = UnitTestHelper.GetDefaultUser();
            long userId = userModel.AddUser(user);

            GroupUser groupUser = new GroupUser();
            groupUser.UserId=(int)userId;
            groupUser.GroupId=(int)groupId;

            long groupUserId = groupUserModel.AddGroupUser(groupUser);
        }

        Message message = UnitTestHelper.GetMessage(MessageMethod.EMAIL);
        message.GroupId=(int)groupId;

        Calendar calendar = Calendar.getInstance(); // gets a calendar using the default time zone and locale.
        calendar.add(Calendar.MINUTE, 1);
        System.out.println(calendar.getTime());

        message.DateTime = MessageModel.GetDate(calendar);
        long MessageId = messageModel.AddMessage(message);

        message = messageModel.SearchMessage((int)MessageId);

        SMSManager smsManager = new SMSManager(appContext,message,setting);

        Message finalMessage = message;
        UnitTestHelper.LogMessages(new ArrayList<Message>(){{add(finalMessage);}});
        smsManager.Schedule(calendar);

        Thread.sleep(90000);
    }



}
