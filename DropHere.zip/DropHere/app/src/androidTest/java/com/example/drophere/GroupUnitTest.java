package com.example.drophere;

import android.content.Context;
import android.util.Log;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

import com.example.drophere.DAL.BasicModels.Group;
import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbModel.GroupModel;
import com.example.drophere.DAL.DbModel.UserModel;

import java.util.List;
import java.util.Random;

@RunWith(AndroidJUnit4.class)
public class GroupUnitTest {

    GroupModel groupModel;

    @Before
    public void Setup(){
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();

        groupModel = new GroupModel(appContext, "",null,1);
    }
    @Test
    public  void AddGroup(){
        Random rand = new Random();
        int int_random = rand.nextInt(50);

        Group group = new Group();
        group.Name= "Group_"+int_random;
        Long id = groupModel.AddGroup(group);

        Log.d("UnitTest","Group Id: "+id );
        assertTrue(id>0);
    }

    @Test
    public  void UpdateGroup(){
        Random rand = new Random();
        int int_random = rand.nextInt(50);

        Group group = new Group();
        group.Name= "Group_"+int_random;
        long id =  groupModel.AddGroup(group);

        Group updatedGroup = groupModel.SearchGroup((int)id);
        updatedGroup.Name = "Updated_Group";
        groupModel.UpdateGroup(updatedGroup);
        Log.d("UnitTest","Updated Group -> Id: "+updatedGroup.Id+", Name: "+ updatedGroup.Name );

        Group searchedGroup = groupModel.SearchGroup((int)id);

        Log.d("UnitTest","Searched Group -> Id: "+updatedGroup.Id+", Name: "+ updatedGroup.Name);
        assertEquals(searchedGroup.Name,  updatedGroup.Name);
    }
    @Test
    public void ShowGroup(){
        List<Group> groupList = groupModel.ListGroups();

        for (Group group: groupList) {
            Log.d("UnitTest","Group -> Id: "+group.Id +", Name: "+ group.Name);
        }
        Log.d("UnitTest","groups size: "+ groupList.size());
        assertTrue(groupList.size()>0);
    }
    @Test
    public void SearchGroup(){
      /*  List<Group> groupList = groupModel.ListGroups();

        for (Group group: groupList) {
*/
            Group searchedGroup = groupModel.SearchGroup(1);
            assertTrue(searchedGroup!=null);
            Log.d("UnitTest","Group -> Id: "+searchedGroup.Id+", Name: "+ searchedGroup.Name);

        for (User user: searchedGroup.Users) {
            Log.d("UnitTest","Group -> User -> Id: "+user.Id + " , Name: "+ user.Name);

        }

        //}
    }
    @Test
    public void DeleteGroup(){
        Random rand = new Random();
        int int_random = rand.nextInt(50);

        Group group = new Group();
        group.Name= "Group_"+int_random;
        long id = groupModel.AddGroup(group);

        Log.d("UnitTest","Group Added: "+ id );

        groupModel.DeleteGroup((int)id);

        Group searchGroup = groupModel.SearchGroup((int)id);
        assertTrue(searchGroup.Id == 0);

        Log.d("UnitTest","Group -> Name: "+ searchGroup.Name );

    }
}
