package com.example.drophere;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import android.content.Context;
import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import com.example.drophere.DAL.BasicModels.Group;
import com.example.drophere.DAL.BasicModels.GroupUser;
import com.example.drophere.DAL.BasicModels.Message;
import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbModel.GroupModel;
import com.example.drophere.DAL.DbModel.GroupUserModel;
import com.example.drophere.DAL.DbModel.MessageModel;
import com.example.drophere.DAL.DbModel.UserModel;
import com.example.drophere.DAL.MessageMethod;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

@RunWith(AndroidJUnit4.class)
public class MessageUnitTest {

    MessageModel MessageModel;
    GroupModel groupModel;
    UserModel userModel;
    GroupUserModel groupUserModel;

    @Before
    public void Setup(){
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();

        MessageModel = new MessageModel(appContext, "",null,1);
        userModel = new UserModel(appContext,"",null,1);
        groupModel = new GroupModel(appContext,"",null,1);
        groupUserModel = new GroupUserModel(appContext,"",null,1);
    }

    @Test
    public void AddMessageToUser(){

        User user = UnitTestHelper.GetUser();
        long userId = userModel.AddUser(user);

        Message Message = UnitTestHelper.GetMessage(MessageMethod.SMS);
        Message.UserId=(int)userId;

        long MessageId = MessageModel.AddMessage(Message);

        assertTrue(MessageId>0);
    }
    @Test
    public void UpdateMessage(){

        User user = UnitTestHelper.GetUser();
        long userId = userModel.AddUser(user);

        Message Message = UnitTestHelper.GetMessage(MessageMethod.SMS);
        Message.UserId=(int)userId;

        long MessageId = MessageModel.AddMessage(Message);

        Message searchedMessage = MessageModel.SearchMessage((int)MessageId);
        UnitTestHelper.LogMessages( new ArrayList<Message>(){{ add(searchedMessage);}});

        searchedMessage.Status= true;
        searchedMessage.MessageText = "Updated_Message";
        MessageModel.UpdateMessage(searchedMessage);

        Message updatedMessage = MessageModel.SearchMessage((int)MessageId);
        UnitTestHelper.LogMessages( new ArrayList<Message>(){{ add(updatedMessage);}});

        assertTrue(searchedMessage.Status!=false && searchedMessage.MessageText=="Updated_Message");
    }
    @Test
    public void AddMessageToGroup(){

        Group group = UnitTestHelper.GetGroup();
        long groupId = groupModel.AddGroup(group);

        User user = UnitTestHelper.GetUser();
        long userId = userModel.AddUser(user);

        GroupUser groupUser = new GroupUser();
        groupUser.UserId=(int)userId;
        groupUser.GroupId=(int)groupId;

        long groupUserId = groupUserModel.AddGroupUser(groupUser);
        Message message = UnitTestHelper.GetMessage(MessageMethod.SMS);
        message.GroupId = (int)groupId;

        long messageId = MessageModel.AddMessage(message);

        assertTrue(messageId>0);
    }
    @Test
    public void ShowMessage(){

      /*  User user = UnitTestHelper.GetUser();
        long userId = userModel.AddUser(user);

        Message Message = UnitTestHelper.GetMessage();
        Message.UserId=(int)userId;

        long MessageId = MessageModel.AddMessage(Message);*/

        List<Message> Messages = MessageModel.ListMessages();

        UnitTestHelper.LogMessages( Messages);
        assertTrue(Messages.size()>0);
    }
    @Test
    public void DeleteMessage(){

        User user = UnitTestHelper.GetUser();
        long userId = userModel.AddUser(user);

        Message Message = UnitTestHelper.GetMessage(MessageMethod.SMS);
        Message.UserId=(int)userId;

        long MessageId = MessageModel.AddMessage(Message);

        List<Message> Messages = MessageModel.ListMessages();
        UnitTestHelper.LogMessages(Messages);
        int count = Messages.size();
        assertTrue(Messages.size()>0);
        Log.d("UnitTest", "Messages Size: "+Messages.size());

        MessageModel.DeleteMessage((int)MessageId);

        Messages = MessageModel.ListMessages();
        UnitTestHelper.LogMessages( Messages);

        assertTrue(Messages.size() != count);
        Log.d("UnitTest", "Messages Size: "+Messages.size());
    }

}