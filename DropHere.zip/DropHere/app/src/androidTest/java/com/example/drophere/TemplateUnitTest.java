package com.example.drophere;

import android.content.Context;
import android.util.Log;
import android.widget.HeaderViewListAdapter;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

import com.example.drophere.DAL.BasicModels.Template;
import com.example.drophere.DAL.DbModel.TemplateModel;

import java.util.List;
import java.util.Random;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class TemplateUnitTest {
   /* @Test
    public void useAppContext() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertEquals("com.example.drophere", appContext.getPackageName());
    }*/

    TemplateModel templateModel;

    @Before
    public void Setup(){
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();

        templateModel = new TemplateModel(appContext, "",null,1);
    }

    @Test
    public  void AddTemplate(){

        Template template = UnitTestHelper.GetTemplate();
        templateModel.AddTemplate(template);

        List<Template> templateList = templateModel.ListTemplates();

        Log.d("UnitTest","templates size: "+ templateList.size());
        assertTrue(templateList.size()>0);
    }
    @Test
    public  void UpdateTemplate(){
        Random rand = new Random();
        int int_random = rand.nextInt(50);

        Template template = UnitTestHelper.GetTemplate();
        long id =  templateModel.AddTemplate(template);

        Template updatedTemplate = templateModel.SearchTemplate((int)id);
        updatedTemplate.Name = "Updated_Template_"+ int_random;
        templateModel.UpdateTemplate(updatedTemplate);

        Log.d("UnitTest","Updated Template -> Id: "+updatedTemplate.Id+", Name: "+ updatedTemplate.Name  + ", Template: "+updatedTemplate.TemplateText);

        Template searchedTemplate = templateModel.SearchTemplate((int)id);

        Log.d("UnitTest","Searched Template -> Id: "+updatedTemplate.Id+", Name: "+ updatedTemplate.Name  + ", Template: "+updatedTemplate.TemplateText);
        assertEquals(searchedTemplate.Name,  updatedTemplate.Name);
    }
    @Test
    public void ShowTemplate(){
        List<Template> templateList = templateModel.ListTemplates();

        for (Template template: templateList) {
            Log.d("UnitTest","Template -> Id: "+template.Id +", Name: "+ template.Name  + ", Template: "+template.TemplateText);
        }
        Log.d("UnitTest","templates size: "+ templateList.size());
        assertTrue(templateList.size()>0);
    }
    @Test
    public void SearchTemplate(){
        List<Template> templateList = templateModel.ListTemplates();

        for (Template template: templateList) {

            Template searchedTemplate = templateModel.SearchTemplate(template.Id);
            assertTrue(searchedTemplate!=null);
            Log.d("UnitTest","Template -> Id: "+template.Id +", Name: "+ template.Name  + ", Template: "+template.TemplateText);

        }
    }
    @Test
    public void DeleteTemplate(){
        Random rand = new Random();
        int int_random = rand.nextInt(50);

        Template template = UnitTestHelper.GetTemplate();
        long id = templateModel.AddTemplate(template);

        Log.d("UnitTest","Template Added: "+ id );

        templateModel.DeleteTemplate((int)id);

        Template searchTemplate = templateModel.SearchTemplate((int)id);
        assertTrue(searchTemplate.Id == 0);

        Log.d("UnitTest","Template -> Id: "+template.Id +", Name: "+ template.Name  + ", Template: "+template.TemplateText);
    }
}