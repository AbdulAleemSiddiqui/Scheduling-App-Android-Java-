package com.example.drophere;

import android.content.Context;
import android.util.Log;
import android.widget.HeaderViewListAdapter;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbModel.UserModel;

import java.util.List;
import java.util.Random;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class UserUnitTest {
   /* @Test
    public void useAppContext() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertEquals("com.example.drophere", appContext.getPackageName());
    }*/

    UserModel userModel;

    @Before
    public void Setup(){
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();

        userModel = new UserModel(appContext, "",null,1);
    }

    @Test
    public  void AddUser(){

        User user = UnitTestHelper.GetUser();
        userModel.AddUser(user);

        List<User> userList = userModel.ListUsers();

        Log.d("UnitTest","users size: "+ userList.size());
        assertTrue(userList.size()>0);
    }
    @Test
    public  void UpdateUser(){
        User user = UnitTestHelper.GetUser();
        long id =  userModel.AddUser(user);

        User updatedUser = userModel.SearchUser((int)id);
        updatedUser.Name = "Updated_User";
        userModel.UpdateUser(updatedUser);
        Log.d("UnitTest","Updated User -> Id: "+updatedUser.Id+", Name: "+ updatedUser.Name  + ", Email: "+updatedUser.Email+", Phone: "+updatedUser.Phone);

        User searchedUser = userModel.SearchUser((int)id);

        Log.d("UnitTest","Searched User -> Id: "+updatedUser.Id+", Name: "+ updatedUser.Name  + ", Email: "+updatedUser.Email+", Phone: "+updatedUser.Phone);
        assertEquals(searchedUser.Name,  updatedUser.Name);
    }
    @Test
    public void ShowUser(){
        List<User> userList = userModel.ListUsers();

        for (User user: userList) {
            Log.d("UnitTest","User -> Id: "+user.Id +", Name: "+ user.Name  + ", Email: "+user.Email+", Phone: "+user.Phone);
        }
        Log.d("UnitTest","users size: "+ userList.size());
        assertTrue(userList.size()>0);
    }
    @Test
    public void SearchUser(){
        List<User> userList = userModel.ListUsers();

        for (User user: userList) {

            User searchedUser = userModel.SearchUser(user.Id);
            assertTrue(searchedUser!=null);
            Log.d("UnitTest","User -> Id: "+user.Id+", Name: "+ user.Name  + ", Email: "+user.Email+", Phone: "+user.Phone);

        }
    }
    @Test
    public void DeleteUser(){
        Random rand = new Random();
        int int_random = rand.nextInt(50);

        User user = UnitTestHelper.GetUser();
        long id = userModel.AddUser(user);

        Log.d("UnitTest","User Added: "+ id );

        userModel.DeleteUser((int)id);

        User searchUser = userModel.SearchUser((int)id);
        assertTrue(searchUser.Id == 0);

        Log.d("UnitTest","User -> Name: "+ searchUser.Name  + ", Email: "+searchUser.Email+", Phone: "+searchUser.Phone);

    }
}