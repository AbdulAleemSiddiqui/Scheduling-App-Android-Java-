package com.example.drophere;

import android.content.Context;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import com.example.drophere.DAL.DbContext;
import com.example.drophere.DAL.DbModel.TemplateModel;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;

@RunWith(AndroidJUnit4.class)
public class TruncateUnitTest
{
    DbContext context;
    @Before
    public void Setup(){
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();

        context = new TemplateModel(appContext, "",null,1);
    }

    @Test
    public void TruncateAllTables()
    {
        context.TruncateTable(new ArrayList<String>(){{add("MESSAGES");}});
    }
}
