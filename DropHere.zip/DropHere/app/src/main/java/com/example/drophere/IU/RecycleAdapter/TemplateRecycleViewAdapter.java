package com.example.drophere.IU.RecycleAdapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drophere.DAL.BasicModels.Template;
import com.example.drophere.DAL.DbModel.TemplateModel;
import com.example.drophere.R;
import com.example.drophere.TemplateActivity;
import com.example.drophere.TemplateCreateUpdateActivity;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class TemplateRecycleViewAdapter extends RecyclerView.Adapter<TemplateRecycleViewAdapter.TemplateViewHolder> {
    Context context;
    List<Template> templates;
    TemplateModel templateModel;

    public TemplateRecycleViewAdapter(Context context, List<Template> templates) {
        this.context = context;
        this.templates = templates;

        templateModel = new TemplateModel(context, "",null,1);
    }

    @NonNull
    @Override
    public TemplateViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.template_view_item, parent, false);
        return new TemplateViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    public void onBindViewHolder(@NonNull TemplateViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.circleImageView.setImageResource(R.drawable.templateicon);
        holder.templateNameTextView.setText(templates.get(position).Name);
        holder.templateTextTextView.setText(templates.get(position).TemplateText);

        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                templateModel.DeleteTemplate( templates.get(position).Id);

                ((TemplateActivity)context).UpdateCardViewList();
            }
        });


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("LongLogTag")
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, TemplateCreateUpdateActivity.class);
                intent.putExtra("TemplateId", templates.get(position).Id.toString());
                context.startActivity(intent);

                Log.d("TemplateRecylcerViewAdapter","clicked!: "+templates.get(position).Id);
            }
        });
    }

    @Override
    public int getItemCount() {
        return templates.size();
    }

    public class TemplateViewHolder extends RecyclerView.ViewHolder {
        CircleImageView circleImageView;
        TextView templateNameTextView;
        TextView templateTextTextView;
        ImageView deleteButton;

        public TemplateViewHolder(@NonNull View itemView) {
            super(itemView);

            circleImageView = (CircleImageView) itemView.findViewById(R.id.profileImageView);
            templateNameTextView = (TextView) itemView.findViewById(R.id.templateNameTextView);
            templateTextTextView = (TextView) itemView.findViewById(R.id.templateTextTextView);
            deleteButton = (ImageView) itemView.findViewById(R.id.deleteButton);
        }
    }
}