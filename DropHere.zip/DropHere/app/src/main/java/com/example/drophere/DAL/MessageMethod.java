package com.example.drophere.DAL;

import java.io.Serializable;
import java.util.Arrays;

public enum MessageMethod  implements Serializable {
    SMS(0),
    EMAIL(1);
    public final int value;
    MessageMethod(int value) {
        this.value = value;
    }

    public static String[] getNames(Class<? extends Enum<?>> e) {
        return Arrays.toString(e.getEnumConstants()).replaceAll("^.|.$", "").split(", ");
    }
}
