package com.example.drophere.DAL.DbModel;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import androidx.annotation.Nullable;

import com.example.drophere.DAL.DbContext;
import com.example.drophere.DAL.BasicModels.Setting;

import java.util.ArrayList;
import java.util.List;

public class SettingModel extends DbContext
{
    private static final String TAG = "SettingModel";
    String TableName = "SETTINGS";


    public SettingModel(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        Setting defualtSetting = GetDefaultSetting();
        AddSetting(defualtSetting);

        Log.d(TAG, "Default Setting is added");
    }

    public  Setting GetDefaultSetting() {

        Setting setting = new Setting();
        return setting;
    }
    public long AddSetting(Setting setting)
    {
        ContentValues contentValues = Setting.GetContentValues(setting);
        return  this.getWritableDatabase().insertOrThrow(TableName,"",contentValues);
    }
    public void DeleteSetting()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from "+ TableName);
        db.close();
    }

    public void UpdateSetting(Setting setting)
    {
        DeleteSetting();
        AddSetting(setting);
    }

    public List<Setting> ListSettings()
    {
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT * FROM "+TableName, null);
        List<Setting> settingList = new ArrayList<Setting>();

        while (cursor.moveToNext()){

            Setting setting = new Setting();
            setting.Id = cursor.getInt(0);
            setting.Email = cursor.getString(1);
            setting.Password = cursor.getString(2);
            setting.SIM = cursor.getInt(3);
            setting.Signature = cursor.getString(4);
            setting.IsAuthorized = cursor.getInt(5) > 0;
            setting.IsStartTLS = cursor.getInt(6) > 0;
            setting.Host = cursor.getString(7);
            setting.Port = cursor.getString(8);

            settingList.add(setting);
        }

        cursor.close();
        return settingList;
    }

    public Setting SearchSetting(Integer Id)
    {
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT * FROM "+TableName+" WHERE ID="+Id, null);
        Setting searchedSetting = new Setting();

        while (cursor.moveToNext()){
            searchedSetting.Id = cursor.getInt(0);
            searchedSetting.Email = cursor.getString(1);
            searchedSetting.Password = cursor.getString(2);
            searchedSetting.SIM = cursor.getInt(3);
            searchedSetting.Signature = cursor.getString(4);
            searchedSetting.IsAuthorized = cursor.getInt(5) > 0;
            searchedSetting.IsStartTLS = cursor.getInt(6) > 0;
            searchedSetting.Host = cursor.getString(7);
            searchedSetting.Port = cursor.getString(8);
        }

        cursor.close();
        return searchedSetting;
    }

    public Setting SearchSetting()
    {
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT * FROM "+TableName, null);
        Setting searchedSetting = new Setting();

        while (cursor.moveToNext()){
            searchedSetting.Id = cursor.getInt(0);
            searchedSetting.Email = cursor.getString(1);
            searchedSetting.Password = cursor.getString(2);
            searchedSetting.SIM = cursor.getInt(3);
            searchedSetting.Signature = cursor.getString(4);
            searchedSetting.IsAuthorized = cursor.getInt(5) > 0;
            searchedSetting.IsStartTLS = cursor.getInt(6) > 0;
            searchedSetting.Host = cursor.getString(7);
            searchedSetting.Port = cursor.getString(8);
        }

        cursor.close();
        return searchedSetting;
    }
}