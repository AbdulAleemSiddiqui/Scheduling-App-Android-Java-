package com.example.drophere.DAL.BasicModels;

import android.content.ContentValues;

public class GroupUser {

    public Integer Id=0;
    public Integer GroupId=0;
    public Integer UserId=0;


    public static ContentValues GetContentValues(GroupUser groupUser){
        ContentValues contentValues = new ContentValues();
        contentValues.put("GROUPID",groupUser.GroupId);
        contentValues.put("USERID",groupUser.UserId);
        return  contentValues;
    }
}
