package com.example.drophere;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.drophere.DAL.BasicModels.Group;
import com.example.drophere.DAL.BasicModels.Message;
import com.example.drophere.DAL.BasicModels.Template;
import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbModel.Country;
import com.example.drophere.DAL.DbModel.GroupModel;
import com.example.drophere.DAL.DbModel.MessageModel;
import com.example.drophere.DAL.DbModel.TemplateModel;
import com.example.drophere.DAL.DbModel.UserModel;
import com.example.drophere.DAL.MessageMethod;
import com.example.drophere.DAL.MessageRecipient;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

public class MessageActivity extends AppCompatActivity {

    Context currentContext;

    UserModel userModel;
    GroupModel groupModel;
    TemplateModel templateModel;
    Template selectedTemplate;
    Boolean isUserSelected;
    int recipientId;

    MaterialAutoCompleteTextView messageRecipientEditView;
    MaterialAutoCompleteTextView messageRecipientTypeEditView;
    MaterialAutoCompleteTextView messageMethodEditView;
    MaterialAutoCompleteTextView messageTemplateEditView;

    TextInputEditText messageDateEditView;
    TextInputEditText messageTimeEditView;
    Calendar finalCalender = Calendar.getInstance();

    static Boolean activityFinish = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);

        currentContext = this;
        templateModel = new TemplateModel(this, "", null, 1);
        userModel = new UserModel(this, "", null, 1);
        groupModel = new GroupModel(this, "", null, 1);

        messageRecipientEditView = (MaterialAutoCompleteTextView) findViewById(R.id.messageRecipientEditView);
        messageRecipientTypeEditView = (MaterialAutoCompleteTextView) findViewById(R.id.messageRecipientTypeEditView);
        messageMethodEditView = (MaterialAutoCompleteTextView) findViewById(R.id.messageMethodEditView);
        messageTemplateEditView = (MaterialAutoCompleteTextView) findViewById(R.id.messageTemplateEditView);
        messageDateEditView = (TextInputEditText) findViewById(R.id.messageDateEditView);
        messageTimeEditView = (TextInputEditText) findViewById(R.id.messageTimeEditView);

        SetDateTimePickers();
        SetMessageMethod();
        SetMessageRecipient();
        SetTemplates();
    }

    public void OpenNextMessageButton(View view) {

        if(CheckAllFields()) {
            String messageMethodText = messageMethodEditView.getText().toString().trim();
            MessageMethod messageMethod = MessageMethod.valueOf(messageMethodText);

            String messageRecipientTypeText = messageRecipientTypeEditView.getText().toString().trim();
            MessageRecipient messageRecipientType = MessageRecipient.valueOf(messageRecipientTypeText);

            Message message = new Message();
            message.MessageTypeId = messageMethod.value;
            message.MessageMethod = messageMethod;
            message.MessageRecipient = messageRecipientType;
            message.FinalCalendar = finalCalender;
            message.DateTime = MessageModel.GetDate(finalCalender);
            message.SelectedTemplate = selectedTemplate;

            if (isUserSelected) {
                message.UserId = recipientId;
                message.User = userModel.SearchUser(recipientId);
            } else {
                message.GroupId = recipientId;
                message.Group = groupModel.SearchGroup(recipientId);
            }
            Intent intent = new Intent(this, MessageComposeActivity.class);
            intent.putExtra("Message", message);
            startActivityForResult(intent, 1);
        }
    }


    public void SetMessageMethod() {
        String[] methods = MessageMethod.getNames(MessageMethod.class);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_dropdown_item_1line, methods);
        //Getting the instance of AutoCompleteTextView
        messageMethodEditView.setThreshold(1);//will start working from first character
        messageMethodEditView.setAdapter(adapter);//setting the adapter data into the AutoCompleteTextView
    }

    public void SetMessageRecipient() {
        String[] recipientTypes = MessageRecipient.getNames(MessageRecipient.class);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_dropdown_item_1line, recipientTypes);
        //Getting the instance of AutoCompleteTextView
        messageRecipientTypeEditView.setThreshold(1);//will start working from first character
        messageRecipientTypeEditView.setAdapter(adapter);//setting the adapter data into the AutoCompleteTextView

        messageRecipientTypeEditView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                messageRecipientEditView.setText("");

                String messageRecipientTypeText = messageRecipientTypeEditView.getText().toString().trim();
                MessageRecipient messageRecipientType = MessageRecipient.valueOf(messageRecipientTypeText);

                switch (messageRecipientType) {
                    case USER:
                        isUserSelected = true;
                        SetUserAdapter();
                        break;
                    case GROUP:
                        isUserSelected = false;
                        SetGroupAdapter();
                        break;
                }
            }
        });
    }

    public void SetGroupAdapter() {
        Log.d("Message", "Group is selected");
        List<Group> groupList = groupModel.ListGroups();

        ArrayAdapter<Group> userArrayAdapter = new ArrayAdapter<Group>
                (currentContext,
                        android.R.layout.simple_dropdown_item_1line,
                        groupList);

        messageRecipientEditView.setThreshold(1);
        messageRecipientEditView.setAdapter(userArrayAdapter);
        messageRecipientEditView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Log.d("Message", "Group ID: " + groupList.get(i).Id + " , Name: " + groupList.get(i).Name);
                recipientId = groupList.get(i).Id;
            }
        });
    }

    public void SetUserAdapter() {
        Log.d("Message", "User is selected");
        List<User> userList = userModel.ListUsers();

        ArrayAdapter<User> userArrayAdapter = new ArrayAdapter<User>
                (currentContext,
                        android.R.layout.simple_dropdown_item_1line,
                        userList);

        messageRecipientEditView.setThreshold(1);
        messageRecipientEditView.setAdapter(userArrayAdapter);
        messageRecipientEditView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.d("Message", "User ID: " + userList.get(i).Id + " , Name: " + userList.get(i).Name);
                recipientId = userList.get(i).Id;
            }
        });
    }

    public void SetTemplates() {

        List<Template> templateList = templateModel.ListTemplates();

        ArrayAdapter<Template> adapter = new ArrayAdapter<Template>
                (this, android.R.layout.simple_dropdown_item_1line, templateList);
        //Getting the instance of AutoCompleteTextView
        messageTemplateEditView.setThreshold(1);//will start working from first character
        messageTemplateEditView.setAdapter(adapter);//setting the adapter data into the AutoCompleteTextView
        messageTemplateEditView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                selectedTemplate = templateList.get(i);
                Log.d("Message", "ID: " + selectedTemplate.Id);
            }
        });
    }


    public void SetDateTimePickers() {

        Calendar calendar = Calendar.getInstance();

        int YEAR = calendar.get(Calendar.YEAR);
        int MONTH = calendar.get(Calendar.MONTH);
        int DATE = calendar.get(Calendar.DATE);
        int HOUR = calendar.get(Calendar.HOUR);
        int MINUTES = calendar.get(Calendar.MINUTE);

        //Set default Date as current
        finalCalender.set(Calendar.YEAR, YEAR);
        finalCalender.set(Calendar.MONTH, MONTH);
        finalCalender.set(Calendar.DATE, DATE);

        CharSequence charSequence = DateFormat.format("dd MMM yyyy", finalCalender);
        messageDateEditView.setText(charSequence);

        //Set Current time as default with 1 plus
        finalCalender.set(Calendar.HOUR, HOUR);
        finalCalender.set(Calendar.MINUTE, MINUTES + 1);
        Log.d("Message", "Time: " + finalCalender.getTime());

        charSequence = DateFormat.format("h:mm a", finalCalender);
        messageTimeEditView.setText(charSequence);


        //Set listeners for date picker
        messageDateEditView.setFocusable(false);
        messageDateEditView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleDateButton();
            }
        });

        messageTimeEditView.setFocusable(false);
        messageTimeEditView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleTimeButton();
            }
        });
    }

    public void handleDateButton() {


        Calendar calendar = Calendar.getInstance();

        int YEAR = calendar.get(Calendar.YEAR);
        int MONTH = calendar.get(Calendar.MONTH);
        int DATE = calendar.get(Calendar.DATE);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int date) {
                finalCalender.set(Calendar.YEAR, year);
                finalCalender.set(Calendar.MONTH, month);
                finalCalender.set(Calendar.DATE, date);

                CharSequence charSequence = DateFormat.format("dd MMM yyyy", finalCalender);
                messageDateEditView.setText(charSequence);
            }
        }, YEAR, MONTH, DATE);

        datePickerDialog.show();
    }

    public void handleTimeButton() {

        Calendar calendar = Calendar.getInstance();

        int HOUR = calendar.get(Calendar.HOUR);
        int MINUTE = calendar.get(Calendar.MINUTE);

        Boolean is24HourFormat = DateFormat.is24HourFormat(this);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int hour, int minutes) {

                finalCalender.set(Calendar.HOUR, hour);
                finalCalender.set(Calendar.MINUTE, minutes);
                Log.d("Message", "Time: " + finalCalender.getTime());

                CharSequence charSequence = DateFormat.format("h:mm a", finalCalender);
                messageTimeEditView.setText(charSequence);
            }
        }, HOUR, MINUTE, is24HourFormat);

        timePickerDialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        finish();
    }



    private boolean CheckAllFields() {

        if (messageRecipientTypeEditView.length() == 0) {
            messageRecipientTypeEditView.setError("Recipient Type field is required");
            return false;
        }
        if (messageRecipientEditView.length() == 0) {
            messageRecipientEditView.setError("Recipient field is required");
            return false;
        }

        if (messageMethodEditView.length() == 0) {
            messageMethodEditView.setError("Message method field is required");
            return false;
        }

        // after all validation return true.
        return true;
    }
}