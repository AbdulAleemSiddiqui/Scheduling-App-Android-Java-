package com.example.drophere.DAL.BasicModels;

import android.content.ContentValues;
import android.util.Log;

import com.example.drophere.DAL.MessageMethod;
import com.example.drophere.DAL.MessageRecipient;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

public class Message implements Serializable {

    public Integer Id = 0;
    public Integer MessageTypeId = 0;
    public Integer UserId = 0 ;
    public Integer GroupId = 0 ;
    public String DateTime = null;
    public String Subject = "";
    public String MessageText = "";
    public String MediaPath = "";
    public Boolean Status = false   ;

    public User User;
    public Group Group;

    public MessageMethod MessageMethod;
    public MessageRecipient MessageRecipient;
    public Calendar FinalCalendar;
    public Template SelectedTemplate;

    public static ContentValues GetContentValues(Message message){
        ContentValues contentValues = new ContentValues();
        contentValues.put("MESSAGETYPEID",message.MessageTypeId);
        contentValues.put("USERID",message.UserId);
        contentValues.put("GROUPID",message.GroupId);
        contentValues.put("DATETIME",message.DateTime);
        contentValues.put("SUBJECT",message.Subject);
        contentValues.put("MESSAGETEXT",message.MessageText);
        contentValues.put("MEDIAPATH",message.MediaPath);
        contentValues.put("STATUS",message.Status);
        return  contentValues;
    }

    public  static  String GetRecipient(Message message)
    {
        if(message.UserId != 0)
        {
            Log.d("Message","User : "+ message.User.Name);
            return message.User.Name;
        }
        else if (message.GroupId != 0)
        {
            Log.d("Message", "Group: "+message.Group.Name);
            return message.Group.Name;
        }
        return "";
    }
}
