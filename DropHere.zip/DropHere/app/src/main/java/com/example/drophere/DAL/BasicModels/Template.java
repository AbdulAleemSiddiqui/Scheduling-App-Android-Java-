package com.example.drophere.DAL.BasicModels;

import android.content.ContentValues;

import java.io.Serializable;

public class Template implements Serializable
{
    public Integer Id = 0;
    public String Name = "";
    public String TemplateText = "";

    public static ContentValues GetContentValues(Template template){
        ContentValues contentValues = new ContentValues();
        contentValues.put("NAME",template.Name);
        contentValues.put("TEMPLATETEXT",template.TemplateText);
        return  contentValues;
    }

    @Override
    public String toString() {
        return Name;
    }
}
