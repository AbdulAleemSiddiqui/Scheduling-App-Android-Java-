package com.example.drophere.DAL.DbModel;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import androidx.annotation.Nullable;

import com.example.drophere.DAL.BasicModels.Group;
import com.example.drophere.DAL.BasicModels.GroupUser;
import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbContext;

import java.util.ArrayList;
import java.util.List;

public class GroupUserModel extends DbContext {

    String TableName = "GROUPUSERS";

    GroupModel groupModel;

    public GroupUserModel(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);

    }

    public List<User> GetGroupUsers(Integer groupId)
    {
        String query = "SELECT u.ID, u.NAME, u.EMAIL, u.PHONE, u.COUNTRY, u.CITY FROM [GROUPUSERS] gu INNER JOIN [USERS] u on u.[ID] = gu.USERID WHERE GROUPID="+groupId;
        Cursor cursor = this.getReadableDatabase().rawQuery(query, null);
        List<User> userList = new ArrayList<User>();

        while (cursor.moveToNext()){

            User user = new User();
            user.Id = cursor.getInt(0);
            user.Name = cursor.getString(1);
            user.Email = cursor.getString(2);
            user.Phone = cursor.getString(3);
            user.Country = cursor.getString(4);
            user.City = cursor.getString(5);

            userList.add(user);
        }

        cursor.close();
        return userList;
    }

    public long AddGroupUser(GroupUser groupUser)
    {
        ContentValues contentValues = GroupUser.GetContentValues(groupUser);
        return  this.getWritableDatabase().insertOrThrow("GROUPUSERS","",contentValues);
    }

    public void AddGroupUser(Group group, List<User> userList)
    {
        for (User user: userList)
        {
            GroupUser groupUser = new GroupUser();
            groupUser.GroupId = group.Id;
            groupUser.UserId = user.Id;

            ContentValues contentValues = GroupUser.GetContentValues(groupUser);
            this.getWritableDatabase().insertOrThrow("GROUPUSERS","",contentValues);

            Log.d("Group:", "Group User Added!!");
        }
    }

    public void RemoveGroupUser(GroupUser groupUser)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE from "+ TableName + " WHERE GROUPID=" +groupUser.GroupId + " AND USERID="+groupUser.UserId);
        db.close();
    }
}
