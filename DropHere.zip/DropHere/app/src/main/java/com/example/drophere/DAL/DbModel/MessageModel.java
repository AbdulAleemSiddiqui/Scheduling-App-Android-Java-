package com.example.drophere.DAL.DbModel;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import androidx.annotation.Nullable;

import com.example.drophere.DAL.BasicModels.Message;
import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbContext;
import com.example.drophere.DAL.MessageMethod;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MessageModel extends DbContext
{
    String TableName = "MESSAGES";
    UserModel userModel;
    GroupModel groupModel;

    public MessageModel(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        userModel = new UserModel(context,name,factory,version);
        groupModel = new GroupModel(context,name,factory,version);
    }


    public long AddMessage(Message message)
    {
        ContentValues contentValues = Message.GetContentValues(message);
        return  this.getWritableDatabase().insertOrThrow(TableName ,"",contentValues);
    }

    public void DeleteMessage(Integer id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TableName, "id = ?", new String[]{id.toString()});
        db.close();
    }

    public void UpdateMessage(Message message)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = Message.GetContentValues(message);
        db.update(TableName, contentValues, "id = ?", new String[]{message.Id.toString()});
        db.close();
    }

    public void UpdateMessageStatus(Integer messageId, Boolean status)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("STATUS",status);

        db.update(TableName, contentValues, "id = ?", new String[]{messageId.toString()});
        db.close();
    }

    public List<Message> ListMessages()
    {
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT * FROM "+TableName , null);
        List<Message> messageList = new ArrayList<Message>();

        while (cursor.moveToNext()){

            Message message = new Message();
            message.Id = cursor.getInt(0);
            message.MessageTypeId = cursor.getInt(1);
            message.UserId = cursor.getInt(2);
            message.GroupId = cursor.getInt(3);
            message.DateTime = cursor.getString(4);
            message.Subject = cursor.getString(5);
            message.MessageText = cursor.getString(6);
            message.MediaPath = cursor.getString(7);
            message.Status = cursor.getInt(8) > 0;

            message.User = userModel.SearchUser(message.UserId);
            message.Group = groupModel.SearchGroup(message.GroupId);
            message.MessageMethod = MessageMethod.values()[message.MessageTypeId];
            messageList.add(message);
        }

        cursor.close();
        return messageList;
    }

    public Message SearchMessage(Integer Id)
    {
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT * FROM [MESSAGES] WHERE ID="+Id, null);
        Message searchedMessage = new Message();

        while (cursor.moveToNext()){
            searchedMessage.Id = cursor.getInt(0);
            searchedMessage.MessageTypeId = cursor.getInt(1);
            searchedMessage.UserId = cursor.getInt(2);
            searchedMessage.GroupId = cursor.getInt(3);
            searchedMessage.DateTime = cursor.getString(4);
            searchedMessage.Subject = cursor.getString(5);
            searchedMessage.MessageText = cursor.getString(6);
            searchedMessage.MediaPath = cursor.getString(7);
            searchedMessage.Status = cursor.getInt(8) > 0;

            searchedMessage.User = userModel.SearchUser(searchedMessage.UserId);
            searchedMessage.Group = groupModel.SearchGroup(searchedMessage.GroupId);
            searchedMessage.MessageMethod = MessageMethod.values()[searchedMessage.MessageTypeId];
        }

        cursor.close();
        return searchedMessage;
    }


    public static String GetDate(Calendar calendar)
    {
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, d MMM yyyy HH:mm ");

        String formattedDate = dateFormat.format(calendar.getTime());
        Log.d("MessageManager :", formattedDate );

        return formattedDate;
    }
}