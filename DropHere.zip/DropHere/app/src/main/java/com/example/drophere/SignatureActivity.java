package com.example.drophere;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.ArrayAdapter;

import com.example.drophere.DAL.BasicModels.Setting;
import com.example.drophere.DAL.DbModel.Country;
import com.example.drophere.DAL.DbModel.SettingModel;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;

public class SignatureActivity extends AppCompatActivity {

    SettingModel settingModel;
    TextInputEditText settingSignatureEditView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signature);

        settingSignatureEditView = (TextInputEditText) findViewById(R.id.settingSignatureEditView);

        settingModel = new SettingModel(this, "", null, 1);

        Setting setting = settingModel.SearchSetting();

        if(settingSignatureEditView != null)
           settingSignatureEditView.setText(setting.Signature);
    }


    public void AddUpdateSetting(View view)
    {
        Setting setting = settingModel.SearchSetting();
        setting.Signature = settingSignatureEditView.getText().toString().trim();
        settingModel.UpdateSetting(setting);

        finish();
    }
}