package com.example.drophere.DAL;

import java.io.Serializable;
import java.util.Arrays;

public enum MessageRecipient implements Serializable
{
    USER(0),
    GROUP(1);
    public final int value;
    MessageRecipient(int value) {
        this.value = value;
    }

    public static String[] getNames(Class<? extends Enum<?>> e) {
        return Arrays.toString(e.getEnumConstants()).replaceAll("^.|.$", "").split(", ");
    }
}
