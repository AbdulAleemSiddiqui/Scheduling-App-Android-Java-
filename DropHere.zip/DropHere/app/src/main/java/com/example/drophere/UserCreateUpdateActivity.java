package com.example.drophere;

import androidx.activity.result.ActivityResult;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Instrumentation;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;

import com.example.drophere.DAL.BasicModels.CustomContact;
import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbModel.Country;
import com.example.drophere.DAL.DbModel.UserModel;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class UserCreateUpdateActivity extends AppCompatActivity {

    private static final int PICK_CONTACT = 1;
    int REQUEST_ID_CONTACT_PICKER = 1001;

    TextInputEditText userNameEditView;
    TextInputEditText userEmailEditView;
    TextInputEditText userPhoneEditView;
    TextInputEditText userCityEditView;
    MaterialAutoCompleteTextView userCountryEditView;

    MaterialTextView titleTextView;
    MaterialButton addUpdateButton;

    UserModel userModel;
    User searchedUser;

    Boolean isCreateMode = false;
    Integer userId = 0;

    @SuppressLint("LongLogTag")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_create_update);

        userNameEditView = (TextInputEditText) findViewById(R.id.userNameEditView);
        userEmailEditView = (TextInputEditText) findViewById(R.id.userEmailEditView);
        userPhoneEditView = (TextInputEditText) findViewById(R.id.userPhoneEditView);
        userCityEditView = (TextInputEditText) findViewById(R.id.userCityEditView);
        userCountryEditView = (MaterialAutoCompleteTextView) findViewById(R.id.userCountryEditView);

        titleTextView = (MaterialTextView) findViewById(R.id.titleTextView);
        addUpdateButton = (MaterialButton) findViewById(R.id.addUpdateButton);

        SetCountries();

        userModel = new UserModel(this, "", null, 1);

        String id = getIntent().getStringExtra("UserId");

        Log.d("UserCreateUpdateActivity", "Intent Id: " + id);


        if (id == null) {
            isCreateMode = true;
            addUpdateButton.setText("Add");
            addUpdateButton.setIcon(ContextCompat.getDrawable(this, R.drawable.ic_baseline_add_24));

            titleTextView.setText("Add User");
        } else {

            userId = Integer.parseInt(id);
            searchedUser = userModel.SearchUser(userId);

            userNameEditView.setText(searchedUser.Name);
            userEmailEditView.setText(searchedUser.Email);
            userPhoneEditView.setText(searchedUser.Phone);
            userCountryEditView.setText(searchedUser.Country);
            userCityEditView.setText(searchedUser.City);

            addUpdateButton.setText("Update");
            addUpdateButton.setIcon(ContextCompat.getDrawable(this, R.drawable.ic_baseline_create_24));

            titleTextView.setText("Update User");
        }
    }

    private boolean CheckAllFields() {
        if (userNameEditView.length() == 0) {
            userNameEditView.setError("User Name field is required");
            return false;
        }

        if (userEmailEditView.length() != 0) {
           if(!userEmailEditView.getText().toString().contains(".com") ||
                   !userEmailEditView.getText().toString().contains("@") ) {
               userEmailEditView.setError("Email is not correct.");
               return false;
           }
        }

        if(userPhoneEditView.length()==0 && userEmailEditView.length()==0)
        {
            userPhoneEditView.setError("Enter any contact details");
            return false;
        }

        // after all validation return true.
        return true;
    }

    public void SetCountries() {
        String[] countries = Country.GetCountries();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_dropdown_item_1line, countries);
        //Getting the instance of AutoCompleteTextView
        userCountryEditView.setThreshold(1);//will start working from first character
        userCountryEditView.setAdapter(adapter);//setting the adapter data into the AutoCompleteTextView
    }

    @SuppressLint("LongLogTag")
    public void AddUpdateUser(View view) {

        if(CheckAllFields()) {
            String userName = userNameEditView.getText().toString().trim();
            String userEmail = userEmailEditView.getText().toString().trim();
            String userPhone = userPhoneEditView.getText().toString().trim();
            String userCountry = userCountryEditView.getText().toString().trim();
            String userCity = userCityEditView.getText().toString().trim();

            User user = new User() {{
                Name = userName;
                Phone = userPhone;
                Email = userEmail;
                Country = userCountry;
                City = userCity;
            }};


            if (isCreateMode) {
                long id = userModel.AddUser(user);
                Log.d("UserCreateUpdateActivity", "New User Added: " + id);

            } else {
                user.Id = userId;
                userModel.UpdateUser(user);
                Log.d("UserCreateUpdateActivity", "Update User");
            }
            finish();
        }
    }

    public void OpenContactActivity(View view) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CONTACTS}, 10);
        }

        Intent contactsIntent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
        startActivityForResult(contactsIntent, 1);
    }

    @SuppressLint("Range")
    @Override
    public void onActivityResult(int reqCode, int resultCode, Intent data) {
        super.onActivityResult(reqCode, resultCode, data);

        if (reqCode == 1) {
            if (resultCode == RESULT_OK) {
                Log.d("ContactsH", "ResOK");
                Uri contactData = data.getData();

                CustomContact customContact = CustomContact.fetchAndBuildContact(this, contactData);

                userNameEditView.setText(customContact.givenName);

                if (customContact.emailId != null)
                    userEmailEditView.setText(customContact.emailId);

                if (customContact.contactNumber != null)
                    userPhoneEditView.setText(customContact.contactNumber);

                if (customContact.country != null)
                    userCountryEditView.setText(customContact.country);
            }
        } else {
            Log.d("ContactsH", "Canceled");
        }
    }
}