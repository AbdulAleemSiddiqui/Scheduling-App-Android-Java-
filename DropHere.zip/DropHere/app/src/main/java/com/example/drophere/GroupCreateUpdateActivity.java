package com.example.drophere;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.drophere.DAL.BasicModels.Group;
import com.example.drophere.DAL.BasicModels.GroupUser;
import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbModel.Country;
import com.example.drophere.DAL.DbModel.GroupModel;
import com.example.drophere.DAL.DbModel.GroupUserModel;
import com.example.drophere.DAL.DbModel.UserModel;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public class GroupCreateUpdateActivity extends AppCompatActivity {

    MaterialAutoCompleteTextView groupMembersEditView;
    MaterialButton addUpdateButton;
    MaterialTextView titleTextView;
    MaterialTextView filterTextView;
    TextInputEditText groupNameEditView;
    ChipGroup groupMembersChipGroup;
    TextInputEditText groupCityEditView;
    MaterialAutoCompleteTextView groupCountryEditView;
    ConstraintLayout linearLayout;

    UserModel userModel;
    GroupModel groupModel;
    GroupUserModel groupUserModel;

    ArrayAdapter<String> countriesAdapter;
    List<User> userList;
    List<String> countries;
    static List<User> selectedUsers;
    private boolean isCreateMode;
    private int groupId;
    private Group searchedGroup;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_create_update);

        selectedUsers = new ArrayList<>();
        groupMembersEditView = (MaterialAutoCompleteTextView) findViewById(R.id.groupMembersEditView);
        groupMembersChipGroup = (ChipGroup) findViewById(R.id.groupMembersChipGroup);
        addUpdateButton = (MaterialButton) findViewById(R.id.addUpdateButton);
        titleTextView = (MaterialTextView) findViewById(R.id.titleTextView);
        filterTextView = (MaterialTextView) findViewById(R.id.filterTextView);
        groupNameEditView = (TextInputEditText) findViewById(R.id.groupNameEditView);
        groupCityEditView = (TextInputEditText) findViewById(R.id.groupCityEditView);
        groupCountryEditView = (MaterialAutoCompleteTextView) findViewById(R.id.groupCountryEditView);
        linearLayout = (ConstraintLayout) findViewById(R.id.linearLayout);

        userModel = new UserModel(this, "", null, 1);
        groupModel = new GroupModel(this, "", null, 1);
        groupUserModel = new GroupUserModel(this, "", null, 1);

        String id = getIntent().getStringExtra("GroupId");

        userList  = userModel.ListUsers();

        UpdateGroupOnCreate(id);
        SetContacts();
        SetCountries();
        InitiateFilter();

        Log.d("Group:", "Intent Id: " + id);
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void InitiateFilter(){

        groupCountryEditView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String countryName = editable.toString().trim();

                Log.d("aaa","Selected: "+countryName);

                List<User> filteredUserList = userList.
                        stream()
                        .filter(u -> u.Country.equals(countryName))
                        .collect(Collectors.toList());

                Log.d("aaa","Filtered Size: "+filteredUserList.size());

                if(filteredUserList.size() > 0) {
                    userList = filteredUserList;
                }
                else
                {
                    userList = userModel.ListUsers();
                }
                SetContacts();

            }
        });

        groupCityEditView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String cityName = editable.toString().trim();

                Log.d("aaa","Selected: "+cityName);

                List<User> filteredUserList = userList
                        .stream()
                        .filter(u -> u.City.toLowerCase(Locale.ROOT).equals(cityName.toLowerCase(Locale.ROOT)))
                        .collect(Collectors.toList());

                Log.d("aaa","Filtered Size: "+filteredUserList.size());

                if(filteredUserList.size() > 0) {
                    userList = filteredUserList;
                    SetContacts();
                }


            }
        });

    }


    public void SetCountries() {
        countries = Arrays.asList(Country.GetCountries());

        countriesAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_dropdown_item_1line, countries);
        //Getting the instance of AutoCompleteTextView
        groupCountryEditView.setThreshold(1);//will start working from first character
        groupCountryEditView.setAdapter(countriesAdapter);//setting the adapter data into the AutoCompleteTextView
    }

    public void UpdateGroupOnCreate(String id){

        if (id == null) {
            isCreateMode = true;
            addUpdateButton.setText("Add");
            addUpdateButton.setIcon(ContextCompat.getDrawable(this, R.drawable.ic_baseline_add_24));

            titleTextView.setText("Add Group");
        }
        else {

            groupId = Integer.parseInt(id);
            searchedGroup = groupModel.SearchGroup(groupId);

            groupNameEditView.setText(searchedGroup.Name);
            selectedUsers = searchedGroup.Users;

            Log();
            UpdateChips();

            addUpdateButton.setText("Update");
            addUpdateButton.setIcon(ContextCompat.getDrawable(this, R.drawable.ic_baseline_create_24));

            titleTextView.setText("Update Group");
        }

    }

    public void SetContacts() {
        ArrayAdapter<User> adapter = new ArrayAdapter<User>(this, android.R.layout.simple_dropdown_item_1line, userList);
        groupMembersEditView.setAdapter(adapter);

        groupMembersEditView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                                    long arg3) {

                User selectedUser = userList.get(arg2);
                selectedUsers.add(selectedUser);
                UpdateChips();
                Log();
            }
        });
    }

    public void UpdateChips() {
        groupMembersChipGroup.removeAllViews();

        for (User user: selectedUsers) {

            Chip chip = new Chip(this);
            chip.setText(user.Name);
            chip.setChipBackgroundColorResource(R.color.gray);
            chip.setCloseIconVisible(true);
            chip.setChipIconVisible(true);
            chip.setChipIcon(getResources().getDrawable(getResources()
                    .getIdentifier("usericon", "drawable", getPackageName())));

            chip.setOnCloseIconClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.d("Group:", "Size: "+ selectedUsers.size());
                    selectedUsers.remove(GetUserIndex(user.Name));
                    Log.d("Group:", "Size: "+ selectedUsers.size());
                    groupMembersChipGroup.removeView(chip);
                    Log();
                }
            });

            chip.setTextAppearance(R.style.ChipTextStyleAppearance);
            groupMembersChipGroup.addView(chip);
        }
    }

    public void Log(){

        Log.d("aaa","User List Items: "+userList.size());

        for (User user: userList) {
            Log.d("aaa", "User ID: "+ user.Id+"User Name: "+user.Name+"User Country: "+user.Country);
        }
    }

    public User GetUserIndex(String name) {
        for (int i = 0; i < selectedUsers.size(); i++) {

            if(selectedUsers.get(i).Name == name)
            {
                return selectedUsers.get(i);
            }
        }
        return null;
    }

    public void AddUpdateGroup(View view) {

        Log.d("Group:", "Button clicked!!");

        if(CheckAllFields()) {
            Group group = new Group();
            group.Name = groupNameEditView.getText().toString().trim();

            if (isCreateMode) {
                long groupId = groupModel.AddGroup(group);
                group.Id = (int) groupId;

                groupUserModel.AddGroupUser(group, selectedUsers);

            } else {

                //Update Group
                group.Id = groupId;
                Log.d("Group:", "Group ID = " + group.Id);
                groupModel.UpdateGroup(group);
                Log();

                //Update Group User
                groupModel.UpdateGroupUser(group, selectedUsers);
            }
            finish();
        }
    }

    public void OpenCloseFilter(View view) {

        if(linearLayout.getVisibility()==View.VISIBLE)
        {
            filterTextView.setText("Filter Your User +");
            linearLayout.setVisibility(View.GONE);
        }
        else {
            filterTextView.setText("Filter Your User -");
            linearLayout.setVisibility(View.VISIBLE);
        }
    }

    private boolean CheckAllFields() {
        if (groupNameEditView.length() == 0) {
            groupNameEditView.setError("Group Name field is required");
            return false;
        }

        if (groupMembersChipGroup.getChildCount() == 0) {
            groupMembersEditView.setError("Must add any group members");
            return false;
        }

        // after all validation return true.
        return true;
    }

}