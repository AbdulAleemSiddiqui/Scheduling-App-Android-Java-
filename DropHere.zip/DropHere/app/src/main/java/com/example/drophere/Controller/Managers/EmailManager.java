package com.example.drophere.Controller.Managers;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.webkit.MimeTypeMap;

import androidx.annotation.RequiresApi;
import androidx.test.platform.app.InstrumentationRegistry;

import com.example.drophere.Controller.SchedularTask;
import com.example.drophere.DAL.BasicModels.Message;
import com.example.drophere.DAL.BasicModels.Setting;
import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbModel.GroupUserModel;
import com.example.drophere.DAL.DbModel.MessageModel;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Timer;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

public class EmailManager implements MessageManager{

    Context context;
    Message messageInfo;
    Setting setting;
    MessageModel messageModel;
    GroupUserModel groupUserModel;

    public EmailManager(Context context, Message messageInfo, Setting setting){
        this.messageInfo = messageInfo;
        this.setting = setting;

        this.context = context;
        groupUserModel = new GroupUserModel(context, "",null,1);
        messageModel = new MessageModel(context, "",null,1);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    @Override
    public Boolean Send()
    {
       if(messageInfo.User != null && messageInfo.UserId != 0)
       {
           SendToIndividual(messageInfo.User.Email);
       }
       else if(messageInfo.Group != null && messageInfo.GroupId != 0)
       {
           List<User> groupUsers = new ArrayList<>();
           groupUsers = groupUserModel.GetGroupUsers(messageInfo.GroupId);

           for (User groupUser: groupUsers) {
               SendToIndividual(groupUser.Email);
           }
       }

       messageModel.UpdateMessageStatus(messageInfo.Id, true);

       return true;
    }

    public Boolean SendToIndividual(String emailTo)
    {
        String subject = messageInfo.Subject;
        String message = messageInfo.MessageText;

        message = AddSignature();

        final String emailFrom = setting.Email;
        final String password = setting.Password;

        Uri selectedFile = null;
        Log.d("Result","In Manager Path: "+ messageInfo.MediaPath);
        if(messageInfo.MediaPath != null && !messageInfo.MediaPath.equals(""))
            selectedFile = Uri.fromFile(new File(messageInfo.MediaPath));

        Properties properties = new Properties();
        properties.put("mail.smtp.auth", setting.IsAuthorized);
        properties.put("mail.smtp.starttls.enable", setting.IsStartTLS);
        properties.put("mail.smtp.host", setting.Host);
        properties.put("mail.smtp.port", setting.Port);

        Session session = Session.getInstance(properties,
                new javax.mail.Authenticator(){

                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(emailFrom, password);
                    }
                });

        //It's time to send the email
        try
        {
            javax.mail.Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(emailFrom));
            msg.setRecipients(
                    javax.mail.Message.RecipientType.TO,
                    InternetAddress.parse(emailTo));

            msg.setSubject(subject);

            Log.d("Result","In Manager Message is praping");

            Multipart mp = SetMailBody(selectedFile, message);
            msg.setContent(mp);

            Log.d("Result","In Manager body is ready");
            Transport.send(msg);

            Log.d("Result","Sended To: "+ emailTo);
            return  true;
        }
        catch (MessagingException exception)
        {
            exception.printStackTrace();
        } catch (Exception exception) {
            exception.printStackTrace();
        }

        return false;
    }
    @Override
    public Boolean Schedule(Calendar calendar) {

        //the Date and time at which you want to execute
        Date date = calendar.getTime();

        //Now create the time and schedule it
        Timer timer = new Timer();
        timer.schedule(new SchedularTask(this), date);
        return true;
    }

    @Override
    public String AddSignature()
    {
        Log.d("Result","Message before signature: "+ messageInfo.MessageText);
        Log.d("Result","Setting signature: "+ setting.Signature);

        if(setting.Signature != null && !setting.Signature.equals(""))
        {
            messageInfo.MessageText += System.lineSeparator()+ System.lineSeparator() + setting.Signature;
        }
        Log.d("Result","Message before signature: "+ messageInfo.MessageText);

        return messageInfo.MessageText;
    }

    public Multipart SetMailBody(Uri fileUri,String bodyMessage) throws Exception {

        Multipart _multipart;
        _multipart = new MimeMultipart();

        //First add the text in the body
        BodyPart textBodyPart = new MimeBodyPart();
        textBodyPart.setText(bodyMessage);

        _multipart.addBodyPart(textBodyPart);

        if(fileUri != null) {
            InputStream iStream = null;
            String mimeType = GetMimeType(fileUri);
            String fileName = fileUri.getLastPathSegment();
            iStream = context.getContentResolver().openInputStream(fileUri);

            //Now add the attachment in the body
            BodyPart mediaBodyPart = new MimeBodyPart();
            DataSource source = new ByteArrayDataSource(iStream, mimeType);
            mediaBodyPart.setDataHandler(new DataHandler(source));
            mediaBodyPart.setFileName(fileName);
            _multipart.addBodyPart(mediaBodyPart);
        }
        return  _multipart;
    }

    public String GetMimeType(Uri uri) {
        String mimeType = null;
        if (ContentResolver.SCHEME_CONTENT.equals(uri.getScheme()))
        {
            ContentResolver cr = context.getContentResolver();
            mimeType = cr.getType(uri);
        }
        else
        {
                String fileExtension = MimeTypeMap.getFileExtensionFromUrl(uri
                    .toString());
                mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                    fileExtension.toLowerCase());
        }
        return mimeType;
    }
}
