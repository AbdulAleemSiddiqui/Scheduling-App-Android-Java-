package com.example.drophere;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.drophere.DAL.BasicModels.Group;
import com.example.drophere.DAL.BasicModels.Template;
import com.example.drophere.DAL.DbModel.GroupModel;
import com.example.drophere.DAL.DbModel.TemplateModel;
import com.example.drophere.IU.RecycleAdapter.GroupRecycleViewAdapter;
import com.example.drophere.IU.RecycleAdapter.TemplateRecycleViewAdapter;

import java.util.List;

public class GroupActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    GroupRecycleViewAdapter viewAdapter;
    GroupModel groupModel;

    TextView empty_view;
    ImageView groupError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group);

        empty_view = (TextView) findViewById(R.id.empty_view);
        groupError = (ImageView) findViewById(R.id.groupError);

        recyclerView = (RecyclerView) findViewById(R.id.groupRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        groupModel = new GroupModel(this, "",null,1);

        UpdateCardViewList();
    }


    @Override
    public void onResume(){
        super.onResume();
        UpdateCardViewList();
    }

    public void UpdateCardViewList(){
        List<Group> groupList = groupModel.ListGroups();

        if(groupList.size() > 0) {
            viewAdapter = new GroupRecycleViewAdapter(this, groupList);
            recyclerView.setAdapter(viewAdapter);
            recyclerView.setVisibility(View.VISIBLE);

            empty_view.setVisibility(View.GONE);
            groupError.setVisibility(View.GONE);
        }
        else
        {
            recyclerView.setVisibility(View.GONE);
            empty_view.setVisibility(View.VISIBLE);
            groupError.setVisibility(View.VISIBLE);
        }
    }

    public void OpenGroupAddUpdateActivity(View view) {
        Intent intent = new Intent(this, GroupCreateUpdateActivity.class);
        this.startActivity(intent);
    }
}