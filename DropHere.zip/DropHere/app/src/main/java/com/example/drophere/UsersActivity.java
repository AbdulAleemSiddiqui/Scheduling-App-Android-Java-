package com.example.drophere;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.drophere.DAL.BasicModels.Message;
import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbModel.MessageModel;
import com.example.drophere.DAL.DbModel.UserModel;
import com.example.drophere.IU.RecycleAdapter.MessageRecycleViewAdapter;
import com.example.drophere.IU.RecycleAdapter.TemplateRecycleViewAdapter;
import com.example.drophere.IU.RecycleAdapter.UserRecycleViewAdapter;

import java.util.List;

public class UsersActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    UserRecycleViewAdapter viewAdapter;
    UserModel userModel;
    TextView empty_view;
    ImageView userError;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);

        empty_view = (TextView) findViewById(R.id.empty_view);
        userError  = (ImageView) findViewById(R.id.userError);

        recyclerView  = (RecyclerView) findViewById(R.id.userRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        userModel = new UserModel(this, "",null,1);

        UpdateCardViewList();
    }

    @Override
    public void onResume(){
        super.onResume();
        UpdateCardViewList();
    }

    public void UpdateCardViewList(){
        List<User> userList = userModel.ListUsers();

        if(userList.size() > 0) {
            viewAdapter = new UserRecycleViewAdapter(this, userList);
            recyclerView.setAdapter(viewAdapter);
            recyclerView.setVisibility(View.VISIBLE);

            empty_view.setVisibility(View.GONE);
            userError.setVisibility(View.GONE);
        }
        else
        {
            recyclerView.setVisibility(View.GONE);
            empty_view.setVisibility(View.VISIBLE);
            userError.setVisibility(View.VISIBLE);
        }
    }
    public void OpenUserAddUpdateActivity(View view )
    {
        Intent intent = new Intent(this, UserCreateUpdateActivity.class);
        this.startActivity(intent);
    }
}