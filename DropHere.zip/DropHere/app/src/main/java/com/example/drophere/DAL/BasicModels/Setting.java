package com.example.drophere.DAL.BasicModels;

import android.content.ContentValues;

public class Setting
{

    public Integer Id = 0;
    public String Email = "galioistheway@gmail.com";
    public String Password = "Durand1995";
    public Integer SIM = 2;
    public String Signature = "";
    public Boolean IsAuthorized = true;
    public Boolean IsStartTLS = true;
    public String Host = "smtp.gmail.com";
    public String Port = "587";


    public static ContentValues GetContentValues(Setting setting){
        ContentValues contentValues = new ContentValues();
        contentValues.put("ID",setting.Id);
        contentValues.put("EMAIL",setting.Email);
        contentValues.put("PASSWORD",setting.Password);
        contentValues.put("SIM",setting.SIM);
        contentValues.put("SIGNATURE",setting.Signature);
        contentValues.put("ISAUTHENABLED",setting.IsAuthorized);
        contentValues.put("ISSTARTTLS",setting.IsStartTLS);
        contentValues.put("HOST",setting.Host);
        contentValues.put("PORT",setting.Port);
        return  contentValues;
    }
}
