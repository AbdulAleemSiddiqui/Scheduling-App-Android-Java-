package com.example.drophere.DAL.DbModel;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.example.drophere.DAL.DbContext;
import com.example.drophere.DAL.BasicModels.User;

import java.util.ArrayList;
import java.util.List;

public class UserModel extends DbContext
{
    String TableName = "USERS";


    public UserModel(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }


    public long AddUser(User user)
    {
        ContentValues contentValues = User.GetContentValues(user);
        return  this.getWritableDatabase().insertOrThrow("USERS","",contentValues);
    }

    public void DeleteUser(Integer id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TableName, "id = ?", new String[]{id.toString()});
        db.close();
    }

    public void UpdateUser(User user)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = User.GetContentValues(user);
        db.update(TableName, contentValues, "id = ?", new String[]{user.Id.toString()});
        db.close();
    }

    public List<User> ListUsers()
    {
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT * FROM USERS", null);
        List<User> userList = new ArrayList<User>();

        while (cursor.moveToNext()){

            User user = new User();
            user.Id = cursor.getInt(0);
            user.Name = cursor.getString(1);
            user.Phone = cursor.getString(2);
            user.Email = cursor.getString(3);
            user.Country = cursor.getString(4);
            user.City = cursor.getString(5);

            userList.add(user);
        }

        cursor.close();
        return userList;
    }

    public User SearchUser(Integer Id)
    {
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT * FROM USERS WHERE ID="+Id, null);
        User searchedUser = new User();

        while (cursor.moveToNext()){
            searchedUser.Id = cursor.getInt(0);
            searchedUser.Name = cursor.getString(1);
            searchedUser.Phone = cursor.getString(2);
            searchedUser.Email = cursor.getString(3);
            searchedUser.Country = cursor.getString(4);
            searchedUser.City = cursor.getString(5);
        }

        cursor.close();
        return searchedUser;
    }
}
