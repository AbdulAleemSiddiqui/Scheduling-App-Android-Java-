package com.example.drophere.Controller.Managers;

import com.example.drophere.DAL.BasicModels.Message;

import java.util.Calendar;

public interface MessageManager
{
    public Boolean Send();
    public Boolean SendToIndividual(String contact);
    public Boolean Schedule(Calendar calendar);

    public String AddSignature();
}
