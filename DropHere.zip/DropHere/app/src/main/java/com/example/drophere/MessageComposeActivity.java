package com.example.drophere;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.drophere.Controller.Managers.MessageManager;
import com.example.drophere.Controller.Managers.SMSManager;
import com.example.drophere.Controller.MessageFactory;
import com.example.drophere.DAL.BasicModels.Message;
import com.example.drophere.DAL.BasicModels.Setting;
import com.example.drophere.DAL.DbModel.MessageModel;
import com.example.drophere.DAL.DbModel.SettingModel;
import com.example.drophere.DAL.MessageMethod;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import de.hdodenhof.circleimageview.CircleImageView;

public class MessageComposeActivity extends AppCompatActivity {

    TextInputEditText messageSubjectEditView;
    TextInputLayout messageSubjectTextView;
    TextInputEditText messageTextEditView;
TextView imageTextView;
    MaterialButton addAttachment;
    CircleImageView fileImageView;

    Message message;
    MessageModel messageModel;
    SettingModel settingModel;

    String attachmentPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_compose);

        messageModel = new MessageModel(this, "", null, 1);
        settingModel = new SettingModel(this, "", null, 1);

        messageSubjectTextView = (TextInputLayout) findViewById(R.id.messageSubjectTextView);
        imageTextView = (TextView) findViewById(R.id.imageTextView);
        messageSubjectEditView = (TextInputEditText) findViewById(R.id.messageSubjectEditView);
        messageTextEditView = (TextInputEditText) findViewById(R.id.messageTextEditView);
        addAttachment = (MaterialButton) findViewById(R.id.addAttachment);

        SetMessageData();
        SetMessageText();

    }

    public void SetMessageText() {
        if (message.SelectedTemplate != null) {
            String template = message.SelectedTemplate.TemplateText;
            messageTextEditView.setText(template);
        }
    }

    public void SetMessageData() {
        Intent intent = getIntent();
        message = (Message) intent.getSerializableExtra("Message");

        switch (message.MessageMethod) {
            case EMAIL:
                messageSubjectTextView.setVisibility(View.VISIBLE);
                addAttachment.setVisibility(View.VISIBLE);
                break;
            case SMS:
                messageSubjectTextView.setVisibility(View.GONE);
                addAttachment.setVisibility(View.GONE);
                break;
        }
    }

    public void AddUpdateMessage(View view) throws InterruptedException {

     if(CheckAllFields()) {
         CheckPermission();

         message.MessageText = messageTextEditView.getText().toString().trim();

         if (message.MessageMethod == MessageMethod.EMAIL) {
             message.Subject = messageSubjectEditView.getText().toString().trim();
         }

         long messageId = messageModel.AddMessage(message);

         message.Id = (int) messageId;

         Setting setting = settingModel.SearchSetting();
         MessageManager messageManager = MessageFactory.GetMessageInstance(this, message, setting);
         messageManager.Schedule(message.FinalCalendar);

         new MaterialAlertDialogBuilder(this)
                 .setTitle("Confirmation")
                 .setMessage("Your message is scheduled successfully on at " + message.FinalCalendar.getTime().toString())
                 .show();

         Thread thread = new Thread() {
             @Override
             public void run() {
                 try {
                     synchronized (this) {
                         wait(3000);
                     }
                 } catch (InterruptedException ex) {
                 }

                 finish();

             }
         };

         thread.start();
     }
    }

    public void AddAttachment(View view) {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 3);
    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null) {
            Uri selectedImage = data.getData();
            String fileName = selectedImage.getLastPathSegment();


            File file = new File(fileName);
            imageTextView.setText(file.getName());
            message.MediaPath = fileName;

            Toast toast = new Toast(this);
            CircleImageView view = new CircleImageView(this);

            view.setImageURI(selectedImage);

            toast.setView(view);
            toast.show();
        }
    }

    public void CheckPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
        } else {
            ActivityCompat.requestPermissions(this
                    , new String[]{Manifest.permission.SEND_SMS}
                    , 100);
        }
        int REQUEST_EXTERNAL_STORAGE = 1;
        String[] PERMISSIONS_STORAGE = {
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.MANAGE_EXTERNAL_STORAGE
        };
        // Check if we have write permission
        int permission = ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    this,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }
    }


    private boolean CheckAllFields() {
        if (messageTextEditView.length() == 0) {
            messageTextEditView.setError("Message Text field is required");
            return false;
        }

        // after all validation return true.
        return true;
    }
}