package com.example.drophere.DAL.DbModel;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import androidx.annotation.Nullable;

import com.example.drophere.DAL.BasicModels.Group;
import com.example.drophere.DAL.BasicModels.GroupUser;
import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbContext;

import java.util.ArrayList;
import java.util.List;

public class GroupModel extends DbContext
{
    String TableName = "GROUPS";
    GroupUserModel groupUserModel;


    public GroupModel(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        groupUserModel = new GroupUserModel(context,name,factory,version);
    }


    public long AddGroup(Group group)
    {
        ContentValues contentValues = Group.GetContentValues(group);
        return  this.getWritableDatabase().insertOrThrow("GROUPS","",contentValues);
    }

    public void DeleteGroup(Integer id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TableName, "id = ?", new String[]{id.toString()});
        db.close();
    }

    public void UpdateGroup(Group group)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = Group.GetContentValues(group);
        db.update(TableName, contentValues, "id = ?", new String[]{group.Id.toString()});
        db.close();
    }

    public List<Group> ListGroups()
    {
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT * FROM [GROUPS]", null);
        List<Group> groupList = new ArrayList<Group>();

        while (cursor.moveToNext()){

            Group group = new Group();
            group.Id = cursor.getInt(0);
            group.Name = cursor.getString(1);

            groupList.add(group);
        }

        cursor.close();
        return groupList;
    }
    public void UpdateGroupUser(Group group, List<User> userList)
    {
        RemoveGroupUser(group.Id);
       groupUserModel.AddGroupUser(group,userList);
    }

    public void RemoveGroupUser(Integer groupId)
    {
        Log.d("GroupModelff", "gid: "+groupId);
        Group group = SearchGroup(groupId);

        for (User user: group.Users) {
            GroupUser groupUser = new GroupUser();
            groupUser.UserId = user.Id;
            groupUser.GroupId = groupId;
            groupUserModel.RemoveGroupUser(groupUser);
        }
    }
    public Group SearchGroup(Integer Id)
    {
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT * FROM [GROUPS] WHERE ID="+Id, null);
        Group searchedGroup = new Group();

        while (cursor.moveToNext()){
            searchedGroup.Id = cursor.getInt(0);
            searchedGroup.Name = cursor.getString(1);

            searchedGroup.Users = groupUserModel.GetGroupUsers(searchedGroup.Id);
        }

        cursor.close();
        return searchedGroup;
    }


}
