package com.example.drophere;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.drophere.DAL.BasicModels.Message;
import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbModel.MessageModel;
import com.example.drophere.IU.RecycleAdapter.MessageRecycleViewAdapter;
import com.example.drophere.IU.RecycleAdapter.UserRecycleViewAdapter;

import org.w3c.dom.Text;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    MessageRecycleViewAdapter viewAdapter;
    TextView empty_view;
    ImageView messageError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SetLayout();

        empty_view = (TextView) findViewById(R.id.empty_view);
        messageError  = (ImageView) findViewById(R.id.messageError);
        recyclerView  = (RecyclerView) findViewById(R.id.messageRecyclerView);

        UpdateCardViewList();
    }

    @Override
    public void onResume(){
        super.onResume();
        UpdateCardViewList();
    }

    public void UpdateCardViewList(){
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        MessageModel messageModel = new MessageModel(this, "",null,1);

        List<Message> messageList = messageModel.ListMessages();

        if(messageList.size() > 0) {
            viewAdapter = new MessageRecycleViewAdapter(this, messageList);
            recyclerView.setAdapter(viewAdapter);
            recyclerView.setVisibility(View.VISIBLE);

            empty_view.setVisibility(View.GONE);
            messageError.setVisibility(View.GONE);
        }
        else
        {
            recyclerView.setVisibility(View.GONE);
            empty_view.setVisibility(View.VISIBLE);
            messageError.setVisibility(View.VISIBLE);
        }
    }
    public void OpenSignatureActivity(View view)
    {
        startActivity(new Intent(MainActivity.this, SignatureActivity.class));
    }

    public void OpenUserActivity(View view)
    {
        startActivity(new Intent(MainActivity.this, UsersActivity.class));
    }

    public void OpenTemplateActivity(View view)
    {
        startActivity(new Intent(MainActivity.this, TemplateActivity.class));
    }
    public void OpenSettingctivity(View view)
    {
        startActivity(new Intent(MainActivity.this, SettingActivity.class));
    }
    public void OpenGroupActivity(View view)
    {
        startActivity(new Intent(MainActivity.this, GroupActivity.class));
    }
    public void OpenMessageActivity(View view)
    {
        startActivity(new Intent(MainActivity.this, MessageActivity.class));
    }


    public void SetLayout(){
        switch (getResources().getConfiguration().orientation) {
            case Configuration.ORIENTATION_PORTRAIT:
                setContentView(R.layout.activity_main);
                break;
            case Configuration.ORIENTATION_LANDSCAPE:
                setContentView(R.layout.activity_main_horizontal);
                break;
        }
    }
}