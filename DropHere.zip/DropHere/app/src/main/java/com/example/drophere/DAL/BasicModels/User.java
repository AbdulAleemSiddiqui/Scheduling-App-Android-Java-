package com.example.drophere.DAL.BasicModels;

import android.content.ContentValues;

import java.io.Serializable;

public class User  implements Serializable {

    public Integer Id = 0;
    public String Name = "";
    public String Phone = "";
    public String Email = "";
    public String Country = "";
    public String City = "";


    public static ContentValues GetContentValues(User user){
        ContentValues contentValues = new ContentValues();
        contentValues.put("NAME",user.Name);
        contentValues.put("PHONE",user.Phone);
        contentValues.put("EMAIL",user.Email);
        contentValues.put("COUNTRY",user.Country);
        contentValues.put("CITY",user.City);
        return  contentValues;
    }

    @Override
    public String toString() {
        return Name;
    }
}
