package com.example.drophere.IU.RecycleAdapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drophere.DAL.BasicModels.Message;
import com.example.drophere.DAL.DbModel.MessageModel;
import com.example.drophere.MainActivity;
import com.example.drophere.R;
import com.example.drophere.UsersActivity;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class MessageRecycleViewAdapter extends RecyclerView.Adapter<MessageRecycleViewAdapter.MessageViewHolder> {
    Context context;
    List<Message> messages;

    MessageModel messageModel;

    public MessageRecycleViewAdapter(Context context, List<Message> messages) {
        this.context = context;
        this.messages = messages;

        messageModel = new MessageModel(context,"", null,1);
    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.message_view_item, parent, false);
        return new MessageViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    public void onBindViewHolder(@NonNull MessageViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.circleImageView.setImageResource(R.drawable.messageicon);
        holder.statusSwitch.setChecked(messages.get(position).Status);
        holder.dateTimeTextView.setText(messages.get(position).DateTime);
        holder.recipientTextView.setText(Message.GetRecipient(messages.get(position)));

        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                messageModel.DeleteMessage( messages.get(position).Id);

                ((MainActivity)context).UpdateCardViewList();
            }
        });

        if (holder.statusSwitch.isChecked()) {
            holder.statusSwitch.setHighlightColor(Color.GREEN);
        }
        else {
            holder.statusSwitch.setHighlightColor(Color.RED);
            // holder.statusSwitch.setBackgroundColor(Color.RED);
            holder.statusSwitch.setOutlineSpotShadowColor(Color.RED);
            holder.statusSwitch.setUseMaterialThemeColors(true);
            holder.statusSwitch.setOutlineAmbientShadowColor(Color.RED);
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    public class MessageViewHolder extends RecyclerView.ViewHolder {
        CircleImageView circleImageView;
        TextView dateTimeTextView;
        SwitchMaterial statusSwitch;
        TextView recipientTextView;
        ImageView deleteButton;

        public MessageViewHolder(@NonNull View itemView) {
            super(itemView);

            circleImageView = (CircleImageView) itemView.findViewById(R.id.profileImageView);
            dateTimeTextView = (TextView) itemView.findViewById(R.id.dateTimeTextView);
            statusSwitch = (SwitchMaterial) itemView.findViewById(R.id.statusTextView);
            recipientTextView = (TextView) itemView.findViewById(R.id.recipientTextView);
            deleteButton = (ImageView) itemView.findViewById(R.id.deleteButton);
        }
    }
}
