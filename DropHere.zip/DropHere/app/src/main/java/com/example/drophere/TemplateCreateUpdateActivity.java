package com.example.drophere;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.drophere.DAL.BasicModels.Template;
import com.example.drophere.DAL.DbModel.TemplateModel;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;

public class TemplateCreateUpdateActivity extends AppCompatActivity {

    TextInputEditText templateNameEditView;
    TextInputEditText templateTextEditView;

    MaterialTextView titleTextView;
    MaterialButton addUpdateButton;

    Template searchedTemplate;
    TemplateModel templateModel;
    Boolean isCreateMode = false;
    Integer templateId = 0;

    @SuppressLint("LongLogTag")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_template_create_update);

        templateNameEditView = (TextInputEditText) findViewById(R.id.templateNameEditView);
        templateTextEditView = (TextInputEditText) findViewById(R.id.templateTextEditView);

        titleTextView = (MaterialTextView) findViewById(R.id.titleTextView);
        addUpdateButton = (MaterialButton) findViewById(R.id.addUpdateButton);

        templateModel = new TemplateModel(this, "", null, 1);

        String id = getIntent().getStringExtra("TemplateId");

        Log.d("TemplateCreateUpdateActivity", "Intent Id: " + id);


        if (id == null) {
            isCreateMode = true;
            addUpdateButton.setText("Add");
            addUpdateButton.setIcon(ContextCompat.getDrawable(this, R.drawable.ic_baseline_add_24));

            titleTextView.setText("Add Template");
        } else {

            templateId = Integer.parseInt(id);
            searchedTemplate = templateModel.SearchTemplate(templateId);

            templateNameEditView.setText(searchedTemplate.Name);
            templateTextEditView.setText(searchedTemplate.TemplateText);

            addUpdateButton.setText("Update");
            addUpdateButton.setIcon(ContextCompat.getDrawable(this, R.drawable.ic_baseline_create_24));

            titleTextView.setText("Update Template");
        }
    }

    @SuppressLint("LongLogTag")
    public void AddUpdateTemplate(View view) {

        if (CheckAllFields()) {
            String templateName = templateNameEditView.getText().toString().trim();
            String templateText = templateTextEditView.getText().toString().trim();

            Template template = new Template() {{
                Name = templateName;
                TemplateText = templateText;
            }};


            if (isCreateMode) {
                long id = templateModel.AddTemplate(template);
                Log.d("TemplateCreateUpdateActivity", "New Template Added: " + id);

            } else {
                template.Id = templateId;
                templateModel.UpdateTemplate(template);
                Log.d("TemplateCreateUpdateActivity", "Update Template");
            }
            finish();
        }
    }

    private boolean CheckAllFields() {
        if (templateNameEditView.length() == 0) {
            templateNameEditView.setError("Template Name field is required");
            return false;
        }

        if (templateTextEditView.length() == 0) {
            templateTextEditView.setError("Template text field is required");
            return false;
        }

        // after all validation return true.
        return true;
    }


}