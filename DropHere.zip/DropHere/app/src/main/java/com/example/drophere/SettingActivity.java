package com.example.drophere;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.ArrayAdapter;

import com.example.drophere.DAL.BasicModels.Setting;
import com.example.drophere.DAL.DbModel.Country;
import com.example.drophere.DAL.DbModel.SettingModel;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;

public class SettingActivity extends AppCompatActivity {

    SettingModel settingModel;

    TextInputEditText settingEmailEditView;
    TextInputEditText settingPasswordEditView;
    MaterialAutoCompleteTextView settingSimEditView;
    TextInputEditText settingHostEditView;
    TextInputEditText settingPortEditView;

    SwitchMaterial settingIsAuthEditView;
    SwitchMaterial settingIsStartTlsEditView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        settingEmailEditView = (TextInputEditText) findViewById(R.id.settingEmailEditView);
        settingPasswordEditView = (TextInputEditText) findViewById(R.id.settingPasswordEditView);
        settingSimEditView = (MaterialAutoCompleteTextView) findViewById(R.id.settingSimEditView);
        settingHostEditView = (TextInputEditText) findViewById(R.id.settingHostEditView);
        settingPortEditView = (TextInputEditText) findViewById(R.id.settingPortEditView);
        settingIsAuthEditView = (SwitchMaterial) findViewById(R.id.settingIsAuthEditView);
        settingIsStartTlsEditView = (SwitchMaterial) findViewById(R.id.settingIsStartTlsEditView);

        settingModel = new SettingModel(this, "", null, 1);

        UpdateSettingData();

        Integer[] simNo = {1,2};

        ArrayAdapter<Integer> adapter = new ArrayAdapter<Integer>
                (this, android.R.layout.simple_dropdown_item_1line, simNo);
        //Getting the instance of AutoCompleteTextView
        settingSimEditView.setThreshold(1);//will start working from first character
        settingSimEditView.setAdapter(adapter);//setting the adapter data into the AutoCompleteTextView
    }


    public void UpdateSettingData()
    {
        Setting setting = settingModel.SearchSetting();

        settingEmailEditView.setText(setting.Email);
        settingPasswordEditView.setText(setting.Password);
        settingSimEditView.setText(setting.SIM.toString());
        settingHostEditView.setText(setting.Host);
        settingPortEditView.setText(setting.Port);
        settingIsAuthEditView.setChecked(setting.IsAuthorized);
        settingIsStartTlsEditView.setChecked(setting.IsStartTLS);
    }

    public void AddUpdateSetting(View view) {
        if (CheckAllFields()) {
            Setting setting = settingModel.SearchSetting();
            setting.Email = settingEmailEditView.getText().toString().trim();
            setting.Password = settingPasswordEditView.getText().toString().trim();
            ;
            setting.SIM = Integer.parseInt(settingSimEditView.getText().toString().trim());
            setting.Host = settingHostEditView.getText().toString().trim();
            ;
            setting.Port = settingPortEditView.getText().toString().trim();
            ;
            setting.IsAuthorized = settingIsAuthEditView.isChecked();
            setting.IsStartTLS = settingIsStartTlsEditView.isChecked();

            settingModel.UpdateSetting(setting);

            finish();
        }
    }

    private boolean CheckAllFields() {

        if(settingEmailEditView.length() == 0 )
        {
            settingEmailEditView.setError("Email is required");
            return false;
        }
        else if (settingEmailEditView.length() != 0) {
            if(!settingEmailEditView.getText().toString().contains(".com") ||
                    !settingEmailEditView.getText().toString().contains("@") ) {
                settingEmailEditView.setError("Email is not correct.");
                return false;
            }
        }

        if (settingPasswordEditView.length() == 0) {
            settingPasswordEditView.setError("Password field is required");
            return false;
        }
        else if(settingPasswordEditView.length() < 8)
        {
            settingPasswordEditView.setError("Password must be minimum 8 characters");
            return false;
        }

        if(settingSimEditView.length() == 0)
        {
            settingSimEditView.setError("Sim field is required");
            return false;
        }

        if(settingPortEditView.length() == 0)
        {
            settingPortEditView.setError("Port field is required");
            return false;
        }

        if(settingHostEditView.length() == 0)
        {
            settingPortEditView.setError("Host field is required");
            return false;
        }
        // after all validation return true.
        return true;
    }
}