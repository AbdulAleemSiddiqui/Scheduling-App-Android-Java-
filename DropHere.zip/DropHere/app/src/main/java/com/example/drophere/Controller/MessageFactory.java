package com.example.drophere.Controller;

import android.content.Context;

import com.example.drophere.Controller.Managers.EmailManager;
import com.example.drophere.Controller.Managers.MessageManager;
import com.example.drophere.Controller.Managers.SMSManager;
import com.example.drophere.DAL.BasicModels.Message;
import com.example.drophere.DAL.BasicModels.Setting;
import com.example.drophere.DAL.MessageMethod;

public class MessageFactory {

    public static MessageManager GetMessageInstance(Context context, Message messageInfo, Setting setting)
    {
        MessageManager result = null;

        switch (messageInfo.MessageMethod)
        {
            case SMS:
                result = new SMSManager(context,messageInfo,setting);
                break;
            case EMAIL:
                result = new EmailManager(context, messageInfo,setting);
                break;
        }

        return result;
    }
}
