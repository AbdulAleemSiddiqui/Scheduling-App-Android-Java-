package com.example.drophere.Controller;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.example.drophere.Controller.Managers.MessageManager;
import com.example.drophere.DAL.BasicModels.Message;
import com.example.drophere.DAL.BasicModels.Setting;

import java.util.TimerTask;

public class SchedularTask extends TimerTask {

    MessageManager messageManager;

    public SchedularTask(MessageManager messageManager) {
       this. messageManager = messageManager;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    public void run()
    {
        Log.d("Result","Sending");
        messageManager.Send();
    }
}
