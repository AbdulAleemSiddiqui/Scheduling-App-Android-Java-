package com.example.drophere.DAL;

import android.content.ContentValues;
import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import com.example.drophere.DAL.BasicModels.Setting;
import com.example.drophere.DAL.DbModel.SettingModel;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

public class DbContext extends SQLiteOpenHelper
{
    private static final String TAG = "DbContext";

    public DbContext(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "dropit.db", factory, version);

    }

    String createUserTable = "CREATE TABLE USERS ( ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT,PHONE TEXT,EMAIL TEXT,COUNTRY TEXT,CITY TEXT);";
    String createGroupTable = "CREATE TABLE [GROUPS] ( ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT UNIQUE);";
    String createUserGroupTable = "CREATE TABLE GROUPUSERS( ID INTEGER PRIMARY KEY AUTOINCREMENT, GROUPID INTEGER, USERID INTEGER );";
    String createSettingTable = "CREATE TABLE SETTINGS( ID INTEGER PRIMARY KEY AUTOINCREMENT, EMAIL TEXT UNIQUE, PASSWORD TEXT, SIM INTEGER, SIGNATURE TEXT, ISAUTHENABLED BOOLEAN,  ISSTARTTLS BOOLEAN,  HOST TEXT,  PORT INTEGER );";
    String createTemplateTable = "CREATE TABLE TEMPLATES( ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT UNIQUE, TEMPLATETEXT TEXT );";
    String createMessageTable = "CREATE TABLE MESSAGES( ID INTEGER PRIMARY KEY AUTOINCREMENT, MESSAGETYPEID INTEGER, USERID INTEGER, GROUPID INTEGER, DATETIME TEXT, SUBJECT TEXT, MESSAGETEXT TEXT, MEDIAPATH TEXT, STATUS BOOLEAN );";
    String createMessageTypeTable = "CREATE TABLE MESSAGESTYPE( ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT UNIQUE, AGE INTEGER );";

    String settingTable = "SETTINGS";
    String [] createTables = new String[]
            {
                    createUserTable,
                    createGroupTable,
                    createUserGroupTable,
                    createSettingTable,
                    createTemplateTable,
                    createMessageTable,
                    createMessageTypeTable
            };

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        for (int i = 0; i < createTables.length; i++) {
            sqLiteDatabase.execSQL(createTables[i]);

            Log.d(TAG, "Table Created: "+createTables[i]);
        }

        Log.d(TAG, "Tables are created");

        Setting defualtSetting = new Setting();
        ContentValues contentValues = Setting.GetContentValues(defualtSetting);
        sqLiteDatabase.insertOrThrow(settingTable,"",contentValues);

        Log.d(TAG, "Default Setting is updated");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        for (int index = 0; index < createTables.length; index++) {
            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+createTables[i]);
        }
    }

    public void TruncateTable(List<String> tables) {

        for (String tableName: tables) {
            SQLiteDatabase db = this.getWritableDatabase();
            db.execSQL("delete from "+ tableName);
            db.close();
        }
    }
}
