package com.example.drophere.IU.RecycleAdapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drophere.DAL.BasicModels.Group;
import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbModel.GroupModel;
import com.example.drophere.R;
import com.example.drophere.GroupActivity;
import com.example.drophere.GroupCreateUpdateActivity;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class GroupRecycleViewAdapter extends RecyclerView.Adapter<GroupRecycleViewAdapter.GroupViewHolder> {
    Context context;
    List<Group> groups;
    GroupModel groupModel;

    public GroupRecycleViewAdapter(Context context, List<Group> groups) {
        this.context = context;
        this.groups = groups;

        groupModel = new GroupModel(context, "",null,1);
    }

    @NonNull
    @Override
    public GroupViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.group_view_item, parent, false);
        return new GroupViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    public void onBindViewHolder(@NonNull GroupViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.circleImageView.setImageResource(R.drawable.groupicon);

        Group searchedGroup = groupModel.SearchGroup(groups.get(position).Id);

        holder.groupNameTextView.setText(searchedGroup.Name);

        holder.groupMembersTextView.setText(GetMembersName(searchedGroup.Users));

        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                groupModel.DeleteGroup( searchedGroup.Id);

                ((GroupActivity)context).UpdateCardViewList();
            }
        });


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("LongLogTag")
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, GroupCreateUpdateActivity.class);
                intent.putExtra("GroupId", searchedGroup.Id.toString());
                context.startActivity(intent);

                Log.d("GroupRecylcerViewAdapter","clicked!: "+searchedGroup.Id);
            }
        });
    }

    private String GetMembersName(List<User> members)
    {
        String result = "";
        if(members.size() > 0) {
            for (User user : members) {
                result += user.Name + ", ";
            }
            Log.d("Group:", "Group User Name: " + result);

            result = result.substring(0, result.length() - 2);
        }
        else{
            result = "No Group Members";
        }
        return result;
    }

    @Override
    public int getItemCount() {
        return groups.size();
    }

    public class GroupViewHolder extends RecyclerView.ViewHolder {
        CircleImageView circleImageView;
        TextView groupNameTextView;
        TextView groupMembersTextView;
        ImageView deleteButton;

        public GroupViewHolder(@NonNull View itemView) {
            super(itemView);

            circleImageView = (CircleImageView) itemView.findViewById(R.id.profileImageView);
            groupNameTextView = (TextView) itemView.findViewById(R.id.groupNameTextView);
            groupMembersTextView = (TextView) itemView.findViewById(R.id.groupMembersTextView);
            deleteButton = (ImageView) itemView.findViewById(R.id.deleteButton);
        }
    }
}