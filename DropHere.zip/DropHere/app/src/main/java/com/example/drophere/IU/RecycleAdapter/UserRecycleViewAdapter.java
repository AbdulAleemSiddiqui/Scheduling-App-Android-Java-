package com.example.drophere.IU.RecycleAdapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbModel.UserModel;
import com.example.drophere.MainActivity;
import com.example.drophere.R;
import com.example.drophere.UserCreateUpdateActivity;
import com.example.drophere.UsersActivity;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class UserRecycleViewAdapter extends RecyclerView.Adapter<UserRecycleViewAdapter.UserViewHolder> {
    Context context;
    List<User> users;
    UserModel userModel;

    public UserRecycleViewAdapter(Context context, List<User> users) {
        this.context = context;
        this.users = users;

        userModel = new UserModel(context, "",null,1);
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_view_item, parent, false);
        return new UserViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.circleImageView.setImageResource(R.drawable.usericon);
        holder.userNameTextView.setText(users.get(position).Name);
        holder.userPhoneTextView.setText(users.get(position).Phone);
        holder.userEmailTextView.setText(users.get(position).Email);

        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userModel.DeleteUser( users.get(position).Id);

                ((UsersActivity)context).UpdateCardViewList();
            }
        });


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, UserCreateUpdateActivity.class);
                intent.putExtra("UserId", users.get(position).Id.toString());
                context.startActivity(intent);

                Log.d("UserRecylcerViewAdapter","clicked!: "+users.get(position).Id);
            }
        });
    }

    @Override
    public int getItemCount() {
        return users.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {
        CircleImageView circleImageView;
        TextView userNameTextView;
        TextView userPhoneTextView;
        TextView userEmailTextView;
        ImageView deleteButton;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);

            circleImageView = (CircleImageView) itemView.findViewById(R.id.profileImageView);
            userNameTextView = (TextView) itemView.findViewById(R.id.userNameTextView);
            userPhoneTextView = (TextView) itemView.findViewById(R.id.userPhoneTextView);
            userEmailTextView = (TextView) itemView.findViewById(R.id.userEmailTextView);
            deleteButton = (ImageView) itemView.findViewById(R.id.deleteButton);
        }
    }
}