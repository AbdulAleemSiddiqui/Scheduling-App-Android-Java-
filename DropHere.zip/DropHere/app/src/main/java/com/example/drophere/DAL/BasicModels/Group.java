package com.example.drophere.DAL.BasicModels;

import android.content.ContentValues;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Group  implements Serializable {

    public Integer Id = 0;
    public String Name = "";

    public List<User> Users = new ArrayList<User>();

        public static ContentValues GetContentValues(Group user){
            ContentValues contentValues = new ContentValues();
            contentValues.put("NAME",user.Name);
            return  contentValues;
        }


    @Override
    public String toString() {
        return Name;
    }
}
