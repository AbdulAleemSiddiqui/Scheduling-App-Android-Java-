package com.example.drophere.Controller.Managers;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.test.platform.app.InstrumentationRegistry;

import com.example.drophere.Controller.SchedularTask;
import com.example.drophere.DAL.BasicModels.Message;
import com.example.drophere.DAL.BasicModels.Setting;
import com.example.drophere.DAL.BasicModels.User;
import com.example.drophere.DAL.DbModel.GroupUserModel;
import com.example.drophere.DAL.DbModel.MessageModel;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Timer;

public class SMSManager implements MessageManager {

    Message messageInfo;
    Setting setting;
    GroupUserModel groupUserModel;
    MessageModel messageModel;

    public SMSManager(Context context, Message messageInfo, Setting setting){
        this.messageInfo = messageInfo;
        this.setting = setting;
        groupUserModel = new GroupUserModel(context, "",null,1);
        messageModel = new MessageModel(context, "",null,1);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    @Override
    public Boolean Send() {

        if(messageInfo.User != null && messageInfo.UserId != 0)
        {
            SendToIndividual(messageInfo.User.Phone);
        }
        else if(messageInfo.Group != null && messageInfo.GroupId != 0)
        {
            List<User> groupUsers = new ArrayList<>();
            groupUsers = groupUserModel.GetGroupUsers(messageInfo.GroupId);

            for (User groupUser: groupUsers) {
                SendToIndividual(groupUser.Phone);
            }
        }

        messageModel.UpdateMessageStatus(messageInfo.Id, true);
        return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    public Boolean SendToIndividual(String phone){

        Log.d("Result","Sended");
        Log.d("Result","Phone:"+phone );
        Log.d("Result","Message:"+messageInfo.MessageText);
        String sPhone =  phone;
        String sMessage = messageInfo.MessageText;

        sMessage = AddSignature();

        if(!sPhone.equals("") && !sMessage.equals("")){
            Log.d("Result","Inside condition");

            int simID = setting.SIM; //while simID is the slot number of your second simCard
            int inst =  new Integer(simID);
            SmsManager smsManager =  SmsManager.getSmsManagerForSubscriptionId(inst);
            Log.d("Result","Inside condition SIM: "+ simID);

            smsManager.sendTextMessage(sPhone, null, sMessage, null, null);
            Log.d("Result","Send 1");

        }
        else{
            return false;
        }
        return true;
    }
    @Override
    public Boolean Schedule(Calendar calendar) {

        //the Date and time at which you want to execute
        Date date = calendar.getTime();

        //Now create the time and schedule it
        Timer timer = new Timer();
        timer.schedule(new SchedularTask(this), date);
        return true;
    }

    @Override
    public String AddSignature()
    {
        if(setting.Signature != null && !setting.Signature.equals(""))
        {
            messageInfo.MessageText += System.lineSeparator() + System.lineSeparator()+ setting.Signature;
        }
        return messageInfo.MessageText;
    }

    public Boolean Permission(Context context)
    {
        if(ContextCompat.checkSelfPermission(context,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED)
        {
            return true;
        }
        else{
            ActivityCompat.requestPermissions((Activity) context
                    , new String[] { Manifest.permission.SEND_SMS}
                    , 100);
        }
        return false;
    }

}
