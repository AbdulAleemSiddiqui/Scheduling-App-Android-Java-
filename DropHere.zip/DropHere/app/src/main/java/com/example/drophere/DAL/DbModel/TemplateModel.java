package com.example.drophere.DAL.DbModel;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.example.drophere.DAL.DbContext;
import com.example.drophere.DAL.BasicModels.Template;

import java.util.ArrayList;
import java.util.List;

public class TemplateModel extends DbContext
{
    String TableName = "TEMPLATES";


    public TemplateModel(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }


    public long AddTemplate(Template template)
    {
        ContentValues contentValues = Template.GetContentValues(template);
        return  this.getWritableDatabase().insertOrThrow("TEMPLATES","",contentValues);
    }

    public void DeleteTemplate(Integer id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TableName, "id = ?", new String[]{id.toString()});
        db.close();
    }

    public void UpdateTemplate(Template template)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = Template.GetContentValues(template);
        db.update(TableName, contentValues, "id = ?", new String[]{template.Id.toString()});
        db.close();
    }

    public List<Template> ListTemplates()
    {
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT * FROM TEMPLATES", null);
        List<Template> templateList = new ArrayList<Template>();

        while (cursor.moveToNext()){

            Template template = new Template();
            template.Id = cursor.getInt(0);
            template.Name = cursor.getString(1);
            template.TemplateText = cursor.getString(2);

            templateList.add(template);
        }

        cursor.close();
        return templateList;
    }

    public Template SearchTemplate(Integer Id)
    {
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT * FROM TEMPLATES WHERE ID="+Id, null);
        Template searchedTemplate = new Template();

        while (cursor.moveToNext()){
            searchedTemplate.Id = cursor.getInt(0);
            searchedTemplate.Name = cursor.getString(1);
            searchedTemplate.TemplateText = cursor.getString(2);
        }

        cursor.close();
        return searchedTemplate;
    }
}